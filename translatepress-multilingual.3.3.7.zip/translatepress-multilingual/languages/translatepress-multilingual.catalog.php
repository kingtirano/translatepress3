<?php __("License", "translatepress-multilingual"); ?>
<?php __("Your License Key is valid.", "translatepress-multilingual"); ?>
<?php __("Your License Key is invalid.", "translatepress-multilingual"); ?>
<?php __("Your License has expired.", "translatepress-multilingual"); ?>
<?php __("Activate License", "translatepress-multilingual"); ?>
<?php __("Deactivate License", "translatepress-multilingual"); ?>
<?php __("Add a license key", "translatepress-multilingual"); ?>
<?php __("License Key", "translatepress-multilingual"); ?>
<?php __("Manage your license in your %1$s.", "translatepress-multilingual"); ?>
<?php __("Don’t have a TranslatePress AI License Key?", "translatepress-multilingual"); ?>
<?php __("Get a free License Today", "translatepress-multilingual"); ?>
<?php __("Add your License Key", "translatepress-multilingual"); ?>
<?php __("Add your License Key to unlock all premium features. Find the License Key in your", "translatepress-multilingual"); ?>
<?php __("Your license is valid and active.", "translatepress-multilingual"); ?>
<?php __("TranslatePress License", "translatepress-multilingual"); ?>
<?php __("No Active License Detected for this website.", "translatepress-multilingual"); ?>
<?php __("In order to enable Automatic Translation using TranslatePress AI, you need a license key by creating a free account.", "translatepress-multilingual"); ?>
<?php __("Enter your license key", "translatepress-multilingual"); ?>
<?php __("In order to enable Automatic Translation using TranslatePress AI, please enter your license key from", "translatepress-multilingual"); ?>
<?php __("Get Your Free TranslatePress AI License", "translatepress-multilingual"); ?>
<?php __("Generate License", "translatepress-multilingual"); ?>
<?php __("You have a valid %s <strong>license</strong>.", "translatepress-multilingual"); ?>
<?php __("Manage your license & quota on the %s", "translatepress-multilingual"); ?>
<?php __("Get a Free AI License", "translatepress-multilingual"); ?>
<?php __("This website is already activated under a free license. Each website can only use one free license.", "translatepress-multilingual"); ?>
<?php __("This website is already activated under a free license. Each website can only use one free license. Please upgrade to a premium plan for more TranslatePress AI words from %1$s your account %2$s.", "translatepress-multilingual"); ?>
<?php __("Debug Data for License Checking", "translatepress-multilingual"); ?>
<?php __("Debug Data for License Activation", "translatepress-multilingual"); ?>
<?php __("Please update the TranslatePress - Multilingual plugin to version %1$s or higher to ensure %2$s functions correctly.", "translatepress-multilingual"); ?>
<?php __("Please install and activate the TranslatePress - Multilingual plugin", "translatepress-multilingual"); ?>
<?php __("Install & Activate", "translatepress-multilingual"); ?>
<?php __("Please update TranslatePress - Multilingual to version %2$s or newer. Your currently installed version of TranslatePress - Multilingual is no longer compatible with the current version of %1$s.", "translatepress-multilingual"); ?>
<?php __("All TranslatePress functionalities are disabled until then.", "translatepress-multilingual"); ?>
<?php __("Update Now", "translatepress-multilingual"); ?>
<?php __("This TranslatePress add-on has been migrated to the main plugin and is no longer used. You can delete it.", "translatepress-multilingual"); ?>
<?php __("<strong>TranslatePress</strong> requires at least PHP version 5.6.20+ to run. It is the <a href=\"%s\">minimum requirement of the latest WordPress version</a>. Please contact your server administrator to update your PHP version.", "translatepress-multilingual"); ?>
<?php __("TranslatePress", "translatepress-multilingual"); ?>
<?php __("Abilities for managing TranslatePress configuration.", "translatepress-multilingual"); ?>
<?php __("Add a translation language", "translatepress-multilingual"); ?>
<?php __("Adds a translation language to TranslatePress. Enforces the same per-license limit as the settings UI.", "translatepress-multilingual"); ?>
<?php __("WordPress locale code (e.g. fr_FR, de_DE).", "translatepress-multilingual"); ?>
<?php __("Optional URL slug. Defaults to the ISO language code if omitted.", "translatepress-multilingual"); ?>
<?php __("Set TranslatePress license key", "translatepress-multilingual"); ?>
<?php __("Saves a TranslatePress license key and triggers a remote license check, mirroring the onboarding flow.", "translatepress-multilingual"); ?>
<?php __("The license key to activate.", "translatepress-multilingual"); ?>
<?php __("Enable Automatic Translation", "translatepress-multilingual"); ?>
<?php __("Turns on Automatic Translation. A valid TranslatePress license is required only when the resolved engine is TranslatePress AI (mtapi); Google Translate and DeepL do not require one. If no engine is passed and none is configured, defaults to mtapi.", "translatepress-multilingual"); ?>
<?php __("Optional translation-engine slug to select (e.g. \"mtapi\", \"google_translate_v2\", \"deepl\"). When omitted, keeps the already-configured engine, or defaults to \"mtapi\" if none is configured.", "translatepress-multilingual"); ?>
<?php __("List configured languages", "translatepress-multilingual"); ?>
<?php __("Returns the languages currently configured in TranslatePress, including the default language and per-language slug/publish state.", "translatepress-multilingual"); ?>
<?php __("List available language codes", "translatepress-multilingual"); ?>
<?php __("Returns the full catalog of language codes TranslatePress recognizes, with their English names.", "translatepress-multilingual"); ?>
<?php __("Remove a translation language", "translatepress-multilingual"); ?>
<?php __("Removes a configured translation language. The default language cannot be removed without first reassigning the default.", "translatepress-multilingual"); ?>
<?php __("Locale code of the language to remove.", "translatepress-multilingual"); ?>
<?php __("Update a translation language", "translatepress-multilingual"); ?>
<?php __("Replaces the slug and publish status of an already-configured translation language.", "translatepress-multilingual"); ?>
<?php __("Locale code of the language to update.", "translatepress-multilingual"); ?>
<?php __("URL slug for this language.", "translatepress-multilingual"); ?>
<?php __("Whether this language is published on the front end.", "translatepress-multilingual"); ?>
<?php __("Set the default language", "translatepress-multilingual"); ?>
<?php __("Promotes an already-configured language to be the site default. The previous default remains in the translation languages list.", "translatepress-multilingual"); ?>
<?php __("Locale code to promote to default. Must already be a configured translation language.", "translatepress-multilingual"); ?>
<?php __("You do not have permission to manage TranslatePress settings.", "translatepress-multilingual"); ?>
<?php __("Invalid language code. Allowed characters: A-Z, a-z, 0-9, hyphen, underscore.", "translatepress-multilingual"); ?>
<?php __("Language code \"%s\" is not recognized by TranslatePress.", "translatepress-multilingual"); ?>
<?php __("Language \"%s\" is already configured.", "translatepress-multilingual"); ?>
<?php __("Your current license allows up to %d additional language(s). Upgrade or activate a Pro license to add more.", "translatepress-multilingual"); ?>
<?php __("TranslatePress rejected the new language during settings sanitization.", "translatepress-multilingual"); ?>
<?php __("Enabling Automatic Translation with the TranslatePress AI engine requires an active TranslatePress license. Activate a license first with translatepress/set-license-key, or pass a different engine (e.g. \"google_translate_v2\", \"deepl\").", "translatepress-multilingual"); ?>
<?php __("Your license key expired on %s.", "translatepress-multilingual"); ?>
<?php __("Your license key has expired.", "translatepress-multilingual"); ?>
<?php __("Your license key has been disabled.", "translatepress-multilingual"); ?>
<?php __("Your TranslatePress license key is invalid or missing.", "translatepress-multilingual"); ?>
<?php __("Your license key is disabled for this URL. Re-enable it from your TranslatePress account.", "translatepress-multilingual"); ?>
<?php __("License key mismatch. The license you entered does not match the TranslatePress version you have installed.", "translatepress-multilingual"); ?>
<?php __("Your license key has reached its activation limit.", "translatepress-multilingual"); ?>
<?php __("An error occurred while activating the license, please try again.", "translatepress-multilingual"); ?>
<?php __("Language \"%s\" is not currently configured.", "translatepress-multilingual"); ?>
<?php __("The default language cannot be removed. Set another language as default first.", "translatepress-multilingual"); ?>
<?php __("Slug is empty after sanitization. Use only URL-safe characters.", "translatepress-multilingual"); ?>
<?php __("Language \"%s\" is not currently configured. Add it first with translatepress/add-language.", "translatepress-multilingual"); ?>
<?php __("The default language is always published and cannot be unpublished.", "translatepress-multilingual"); ?>
<?php __("Slug \"%1$s\" is already in use by language \"%2$s\".", "translatepress-multilingual"); ?>
<?php __("TranslatePress rejected the new settings during sanitization.", "translatepress-multilingual"); ?>
<?php __("Advanced", "translatepress-multilingual"); ?>
<?php __("Settings saved.", "translatepress-multilingual"); ?>
<?php __("Are you sure you want to remove this item?", "translatepress-multilingual"); ?>
<?php __("Remove", "translatepress-multilingual"); ?>
<?php __("Add", "translatepress-multilingual"); ?>
<?php __("Select...", "translatepress-multilingual"); ?>
<?php __("Your license key is disabled for this URL. Re-enable it from <a target=\"_blank\" href=\"https://translatepress.com/account/?utm_source=wp-dashboard&utm_medium=client-site&utm_campaign=license-deactivated\">https://translatepress.com/account</a> -> Manage Sites.", "translatepress-multilingual"); ?>
<?php __("<p><strong>License key mismatch.</strong> The license you entered doesn’t match the TranslatePress version you have installed.</p><p>Please check that you’ve installed the correct version for your license from your TranslatePress account.</p>", "translatepress-multilingual"); ?>
<?php __("If you have only the free plugin installed but added a paid license, please install the paid plugin from your TranslatePress account.", "translatepress-multilingual"); ?>
<?php __("Upgrade your plan to add more sites. %1$sUpgrade now%2$s", "translatepress-multilingual"); ?>
<?php __("An error occurred, please try again.", "translatepress-multilingual"); ?>
<?php __("You have successfully activated your license", "translatepress-multilingual"); ?>
<?php __("[%s] Low TranslatePress AI Words", "translatepress-multilingual"); ?>
<?php __("upgrade your plan or get extra AI Words", "translatepress-multilingual"); ?>
<?php __("upgrade your plan", "translatepress-multilingual"); ?>
<?php __("TranslatePress AI words are running low on your site.", "translatepress-multilingual"); ?>
<?php __("Current status: %s words remaining", "translatepress-multilingual"); ?>
<?php __("Once the remaining AI words run out, automatic translation through TranslatePress AI will be paused.", "translatepress-multilingual"); ?>
<?php __("To continue translating your content, please %1$s over at %2$s", "translatepress-multilingual"); ?>
<?php __("Manage Notification: %s", "translatepress-multilingual"); ?>
<?php __("Others", "translatepress-multilingual"); ?>
<?php __("Restrict by Language", "translatepress-multilingual"); ?>
<?php __("Exclude from Language", "translatepress-multilingual"); ?>
<?php __("Restrict element to language", "translatepress-multilingual"); ?>
<?php __("Show this element only in one language.", "translatepress-multilingual"); ?>
<?php __("Enable translation", "translatepress-multilingual"); ?>
<?php __("Allow translation to the corresponding language only if the content is written in the default language.", "translatepress-multilingual"); ?>
<?php __("Select language", "translatepress-multilingual"); ?>
<?php __("Choose in which language to show this element.", "translatepress-multilingual"); ?>
<?php __("Exclude element from language", "translatepress-multilingual"); ?>
<?php __("Exclude this element from specific languages.", "translatepress-multilingual"); ?>
<?php __("Select languages", "translatepress-multilingual"); ?>
<?php __("Choose from which languages to exclude this element.", "translatepress-multilingual"); ?>
<?php __("This element will still be visible when you are translating your website through the Translation Editor.", "translatepress-multilingual"); ?>
<?php __("The content of this element should be written in the default language.", "translatepress-multilingual"); ?>
<?php __("<strong>TranslatePress</strong> encountered SQL errors. <a href=\"%s\" title=\"View TranslatePress SQL Errors\">Check out the errors</a>.", "translatepress-multilingual"); ?>
<?php __("Automatic translation has been disabled.", "translatepress-multilingual"); ?>
<?php __("Dismiss this notice.", "translatepress-multilingual"); ?>
<?php __("Logged errors", "translatepress-multilingual"); ?>
<?php __("These are the most recent 5 errors logged by TranslatePress:", "translatepress-multilingual"); ?>
<?php __("Yes", "translatepress-multilingual"); ?>
<?php __("Why are these errors occuring", "translatepress-multilingual"); ?>
<?php __("If TranslatePress detects something wrong when executing queries on your database, it may disable the Automatic Translation feature in order to avoid any extra charging by Google/DeepL. Automatic Translation needs to be manually turned on, after you solve the issues.", "translatepress-multilingual"); ?>
<?php __("The SQL errors detected can occur for various reasons including missing tables, missing permissions for the SQL user to create tables or perform other operations, problems after site migration or changes to SQL server configuration.", "translatepress-multilingual"); ?>
<?php __("What you can do in this situation", "translatepress-multilingual"); ?>
<?php __("Plan A.", "translatepress-multilingual"); ?>
<?php __("Go to Settings -> TranslatePress -> General tab and Save Settings. This will regenerate the tables using your current SQL settings. Check if no more errors occur while browsing your website in a translated language. Look at the timestamps of the errors to make sure you are not seeing the old errors. Only the most recent 5 errors are displayed.", "translatepress-multilingual"); ?>
<?php __("Plan B.", "translatepress-multilingual"); ?>
<?php __("If your problem isn't solved, try the following steps:", "translatepress-multilingual"); ?>
<?php __("Create a backup of your database", "translatepress-multilingual"); ?>
<?php __("Create a copy of each translation table where you encounter errors. You can copy the table within the same database (trp_dictionary_en_us_es_es_COPY for example) -- perform this step only if you want to keep the current translations", "translatepress-multilingual"); ?>
<?php __("Remove the trouble tables by executing the DROP function on them", "translatepress-multilingual"); ?>
<?php __("Go to Settings -> TranslatePress -> General tab and Save Settings. This will regenerate the tables using your current SQL server.", "translatepress-multilingual"); ?>
<?php __("Copy the relevant content from the duplicated tables (trp_dictionary_en_us_es_es_COPY for example) in the newly generated table (trp_dictionary_en_us_es_es) -- perform this step only if you want to keep the current translations", "translatepress-multilingual"); ?>
<?php __("Test it to see if everything is working. If something went wrong, you can restore the backup that you've made at the first step. Check if no more errors occur while browsing your website in a translated language. Look at the timestamps of the errors to make sure you are not seeing the old errors. Only the most recent 5 errors are displayed.", "translatepress-multilingual"); ?>
<?php __("Plan C.", "translatepress-multilingual"); ?>
<?php __("If your problem still isn't solved, try asking your hosting about your errors. The most common issue is missing permissions for the SQL user, such as the Create Tables permission.", "translatepress-multilingual"); ?>
<?php __("Could not install. Try again from <a href=\"%s\" >Plugins Dashboard.</a>", "translatepress-multilingual"); ?>
<?php __("Active", "translatepress-multilingual"); ?>
<?php __("Permission denied.", "translatepress-multilingual"); ?>
<?php __("Invalid nonce.", "translatepress-multilingual"); ?>
<?php __("Settings scope unknown.", "translatepress-multilingual"); ?>
<?php __("Legacy disabled.", "translatepress-multilingual"); ?>
<?php __("Language Switcher", "translatepress-multilingual"); ?>
<?php __("Change language to %s", "translatepress-multilingual"); ?>
<?php __("Automatic Translation", "translatepress-multilingual"); ?>
<?php __("DeepL", "translatepress-multilingual"); ?>
<?php __("Unsupported languages", "translatepress-multilingual"); ?>
<?php __("The selected automatic translation engine does not provide support for these languages.<br>You can still manually translate pages in these languages using the Translation Editor.", "translatepress-multilingual"); ?>
<?php __("General", "translatepress-multilingual"); ?>
<?php __("Glossary", "translatepress-multilingual"); ?>
<?php __("API key validation failed.", "translatepress-multilingual"); ?>
<?php __("API key verification was successful.", "translatepress-multilingual"); ?>
<?php __("Please enter your Google Translate key.", "translatepress-multilingual"); ?>
<?php __("Please enter your DeepL API key.", "translatepress-multilingual"); ?>
<?php __("Not TranslatePress onboarding page.", "translatepress-multilingual"); ?>
<?php __("Step %s does not exist", "translatepress-multilingual"); ?>
<?php __("Welcome", "translatepress-multilingual"); ?>
<?php __("Add Languages", "translatepress-multilingual"); ?>
<?php __("Enable Addons", "translatepress-multilingual"); ?>
<?php __("Finalize", "translatepress-multilingual"); ?>
<?php __("Exit Setup", "translatepress-multilingual"); ?>
<?php __("Upgrade", "translatepress-multilingual"); ?>
<?php __("Nothing here", "translatepress-multilingual"); ?>
<?php __("Your <strong>TranslatePress</strong> license is missing or invalid. <br/>Please %1$sregister your copy%2$s to enable automatic website translation via TranslatePress AI, premium addons, automatic updates and support. Need a license key? %3$sPurchase one now%4$s", "translatepress-multilingual"); ?>
<?php __("Your <strong>TranslatePress</strong> license will expire on %1$s. Please %2$sRenew Your Licence%3$s to continue receiving access to automatic translations via TP AI, premium addons, product downloads and automatic updates. %4$sRenew Now%5$s", "translatepress-multilingual"); ?>
<?php __("Error: ", "translatepress-multilingual"); ?>
<?php __("Something went wrong, please try again.", "translatepress-multilingual"); ?>
<?php __("Your <strong>TranslatePress</strong> license has expired. <br/>Please %1$sRenew Your Licence%2$s to continue receiving access to automatic translations via TranslatePress AI, premium addons, product downloads, and automatic updates. %3$sRenew now %4$s", "translatepress-multilingual"); ?>
<?php __("License key mismatch. The license you entered doesn’t match the <strong>%1$s</strong> version you have installed. <br/>Please check that you’ve installed the correct version for your license from your %2$sTranslatePress account%3$s.", "translatepress-multilingual"); ?>
<?php __("<br/>If you have only the free plugin installed but added a paid license, please install the paid plugin from your TranslatePress account.", "translatepress-multilingual"); ?>
<?php __("You have reached the activation limit for your <strong>%1$s</strong> license. <br/>Manage your active sites from %2$s your account %3$s.", "translatepress-multilingual"); ?>
<?php __("Your license is disabled for this URL. Re-enable it from <a target=\"_blank\" href=\"https://translatepress.com/account/?utm_source=wp-dashboard&utm_medium=client-site&utm_campaign=license-deactivated\">https://translatepress.com/account</a> -> Manage Sites.", "translatepress-multilingual"); ?>
<?php __("%1$s automatic translation requires an active license. Please %2$srenew%3$s your license or purchase a new one %4$shere%5$s.", "translatepress-multilingual"); ?>
<?php __("Please %1$senter%2$s your license key to enable %3$s automatic translation.", "translatepress-multilingual"); ?>
<?php __("You have less than 5,000 TranslatePress AI words remaining. To continue automatically translating your website, please %spurchase additional AI words at a discount from your account%s.", "translatepress-multilingual"); ?>
<?php __(" Error: ", "translatepress-multilingual"); ?>
<?php __("You do not have a valid license for <strong>TranslatePress</strong>. %1$sGet one for free%2$s to get access to TranslatePress AI.", "translatepress-multilingual"); ?>
<?php __("<strong>NEW:</strong> The <strong>Different Domain per Language</strong> add-on is here! Boost your global SEO and create a local experience with country-specific domains like .de or .fr. Upgrade to <a href=\"https://translatepress.com/pricing/?utm_source=wp-dashboard&utm_medium=client-site&utm_campaign=new-addon-ddpl-upsell\" target=\"_blank\">TranslatePress Business or Developer</a> to access it + more premium perks!", "translatepress-multilingual"); ?>
<?php __("<strong>NEW:</strong> The <strong>Different Domain per Language</strong> add-on is here! Boost your global SEO and create a local experience with country-specific domains like .de or .fr. <a href=\"https://translatepress.com/docs/addons/different-domain-per-language/?utm_source=wp-dashboard&utm_medium=client-site&utm_campaign=new-addon-ddpl\" target=\"_blank\">Learn more</a>.", "translatepress-multilingual"); ?>
<?php __("The daily quota for machine translation characters exceeded. Please check the <strong>TranslatePress -> <a href=\"%s\">Automatic Translation</a></strong> page for more information.", "translatepress-multilingual"); ?>
<?php __("Marketing optin", "translatepress-multilingual"); ?>
<?php __("Opt in to our security and feature updates notifications, and non-sensitive diagnostic tracking.", "translatepress-multilingual"); ?>
<?php __("TranslatePress Preferred User Language", "translatepress-multilingual"); ?>
<?php __("Preferred language to navigate the site", "translatepress-multilingual"); ?>
<?php __("The language is automatically set based by the last visited language by the user.", "translatepress-multilingual"); ?>
<?php __("Always use this language", "translatepress-multilingual"); ?>
<?php __("By checking this setting the preferred language will remain the one selected above, without the possibility of being changed in the frontend.<br>This language will be used in different operations such as sending email to the user.", "translatepress-multilingual"); ?>
<?php __("Hello! Seems like you've been using <strong>TranslatePress</strong> for a while now to translate your website. That's awesome! ", "translatepress-multilingual"); ?>
<?php __("If you can spare a few moments to rate it on WordPress.org it would help us a lot (and boost my motivation).", "translatepress-multilingual"); ?>
<?php __("~ Razvan, developer of TranslatePress", "translatepress-multilingual"); ?>
<?php __("Rate TranslatePress on WordPress.org plugin page", "translatepress-multilingual"); ?>
<?php __("Ok, I will gladly help!", "translatepress-multilingual"); ?>
<?php __("No, thanks.", "translatepress-multilingual"); ?>
<?php __("Full Language Names", "translatepress-multilingual"); ?>
<?php __("Short Language Names", "translatepress-multilingual"); ?>
<?php __("Flags with Full Language Names", "translatepress-multilingual"); ?>
<?php __("Flags with Short Language Names", "translatepress-multilingual"); ?>
<?php __("Only Flags", "translatepress-multilingual"); ?>
<?php __("Full Language Names No HTML", "translatepress-multilingual"); ?>
<?php __("Bottom Right", "translatepress-multilingual"); ?>
<?php __("Bottom Left", "translatepress-multilingual"); ?>
<?php __("Top Right", "translatepress-multilingual"); ?>
<?php __("Top Left", "translatepress-multilingual"); ?>
<?php __("Dark", "translatepress-multilingual"); ?>
<?php __("Light", "translatepress-multilingual"); ?>
<?php __("Deactivate", "translatepress-multilingual"); ?>
<?php __("Activate", "translatepress-multilingual"); ?>
<?php __("Invalid language code. Please try again.", "translatepress-multilingual"); ?>
<?php __("Language codes can contain only A-Z a-z 0-9 - _ characters. Check your language codes in TranslatePress General Settings.", "translatepress-multilingual"); ?>
<?php __("Error! Duplicate URL slug values.", "translatepress-multilingual"); ?>
<?php __("You cannot select two languages that have the same <a href=\"https://en.wikipedia.org/wiki/List_of_ISO_639-1_codes\" target=\"_blank\">iso code</a> but different formalities because doing so will lead to duplicate <a href=\"https://developers.google.com/search/docs/specialty/international/localized-versions\" target=\"_blank\">hreflang tags</a>.", "translatepress-multilingual"); ?>
<?php __("Duplicate language detected.<br>Each language can only be added once to ensure accurate translation management.<br> Please change the duplicate language entry and try again. ", "translatepress-multilingual"); ?>
<?php __("Current Language", "translatepress-multilingual"); ?>
<?php __("Opposite Language", "translatepress-multilingual"); ?>
<?php __("Translate Site", "translatepress-multilingual"); ?>
<?php __("Addons", "translatepress-multilingual"); ?>
<?php __("Settings", "translatepress-multilingual"); ?>
<?php __("Pro Features", "translatepress-multilingual"); ?>
<?php __("Need Help?", "translatepress-multilingual"); ?>
<?php __("Recent community discussions", "translatepress-multilingual"); ?>
<?php __("Loading...", "translatepress-multilingual"); ?>
<?php __("Unable to load forum posts", "translatepress-multilingual"); ?>
<?php __("Ask a Question", "translatepress-multilingual"); ?>
<?php __("View All Topics", "translatepress-multilingual"); ?>
<?php __("by", "translatepress-multilingual"); ?>
<?php __("Have a question?", "translatepress-multilingual"); ?>
<?php __("Get help directly from the plugin developers, suggest improvements, or share your feedback!", "translatepress-multilingual"); ?>
<?php __("Tip for faster help:", "translatepress-multilingual"); ?>
<?php __("Include what you tried, what you expected, and what happened. Screenshots help!", "translatepress-multilingual"); ?>
<?php __("Toggle support chat", "translatepress-multilingual"); ?>
<?php __("Ask the community", "translatepress-multilingual"); ?>
<?php __("Close", "translatepress-multilingual"); ?>
<?php __("Empty feed response", "translatepress-multilingual"); ?>
<?php __("Unable to parse feed", "translatepress-multilingual"); ?>
<?php __("Just now", "translatepress-multilingual"); ?>
<?php _n("%d hour ago", "%d hours ago", 1, "translatepress-multilingual"); ?>
<?php _n("%d day ago", "%d days ago", 1, "translatepress-multilingual"); ?>
<?php __("Source", "translatepress-multilingual"); ?>
<?php __("Srcset", "translatepress-multilingual"); ?>
<?php __("Alt attribute", "translatepress-multilingual"); ?>
<?php __("Title attribute", "translatepress-multilingual"); ?>
<?php __("Anchor link", "translatepress-multilingual"); ?>
<?php __("Placeholder attribute", "translatepress-multilingual"); ?>
<?php __("Submit attribute", "translatepress-multilingual"); ?>
<?php __("Text", "translatepress-multilingual"); ?>
<?php __("Video Poster", "translatepress-multilingual"); ?>
<?php __("plural form", "translatepress-multilingual"); ?>
<?php __("one", "translatepress-multilingual"); ?>
<?php __("few", "translatepress-multilingual"); ?>
<?php __("many", "translatepress-multilingual"); ?>
<?php __("other", "translatepress-multilingual"); ?>
<?php __("Saved", "translatepress-multilingual"); ?>
<?php __("Save", "translatepress-multilingual"); ?>
<?php __("Saving translation...", "translatepress-multilingual"); ?>
<?php __("You have unsaved changes!", "translatepress-multilingual"); ?>
<?php __("Discard changes", "translatepress-multilingual"); ?>
<?php __("Discard All", "translatepress-multilingual"); ?>
<?php __("Loading Strings...", "translatepress-multilingual"); ?>
<?php __("Select string to translate...", "translatepress-multilingual"); ?>
<?php __("Close Editor", "translatepress-multilingual"); ?>
<?php __("From", "translatepress-multilingual"); ?>
<?php __("To", "translatepress-multilingual"); ?>
<?php __("Add Media", "translatepress-multilingual"); ?>
<?php __("Other languages", "translatepress-multilingual"); ?>
<?php __("Context", "translatepress-multilingual"); ?>
<?php __("View Website As", "translatepress-multilingual"); ?>
<?php __("Available in our Pro Versions", "translatepress-multilingual"); ?>
<?php __("Select or Upload Media", "translatepress-multilingual"); ?>
<?php __("Use this media", "translatepress-multilingual"); ?>
<?php __("Translate", "translatepress-multilingual"); ?>
<?php __("Translate entire block element", "translatepress-multilingual"); ?>
<?php __("Split block to translate strings individually", "translatepress-multilingual"); ?>
<?php __("Save changes to translation. Shortcut: CTRL(⌘) + S", "translatepress-multilingual"); ?>
<?php __("Navigate to next string in dropdown list. Shortcut: CTRL(⌘) + ALT + Right Arrow", "translatepress-multilingual"); ?>
<?php __("Navigate to previous string in dropdown list. Shortcut: CTRL(⌘) + ALT + Left Arrow", "translatepress-multilingual"); ?>
<?php __("Discard all changes. Shortcut: CTRL(⌘) + ALT + Z", "translatepress-multilingual"); ?>
<?php __("Discard changes to this text box. To discard changes to all text boxes use shortcut: CTRL(⌘) + ALT + Z", "translatepress-multilingual"); ?>
<?php __("Dismiss tooltip", "translatepress-multilingual"); ?>
<?php __("Quick Intro", "translatepress-multilingual"); ?>
<?php __("Are you sure you want to split this phrase into smaller parts?", "translatepress-multilingual"); ?>
<?php __("This string is not ready for translation yet. <br>Try again in a moment...", "translatepress-multilingual"); ?>
<?php __("For this option to work, please update the Browse as other role add-on to the latest version.", "translatepress-multilingual"); ?>
<?php __("To translate slugs, please update the SEO Pack add-on to the latest version.", "translatepress-multilingual"); ?>
<?php __("You can add a new language from <a href=\"%s\">Settings->TranslatePress</a>", "translatepress-multilingual"); ?>
<?php __("However, you can still use TranslatePress to <strong style=\"background: #f5fb9d;\">modify gettext strings</strong> available in your page.", "translatepress-multilingual"); ?>
<?php __("Strings that are user-created cannot be modified, only those from themes and plugins.", "translatepress-multilingual"); ?>
<?php __("Extra Translation Features", "translatepress-multilingual"); ?>
<?php __("Support for 130+ Extra Languages", "translatepress-multilingual"); ?>
<?php __("Access to TranslatePress AI", "translatepress-multilingual"); ?>
<?php __("Translate SEO Title, Description, Slug", "translatepress-multilingual"); ?>
<?php __("Publish only when translation is complete", "translatepress-multilingual"); ?>
<?php __("Translate by Browsing as User Role", "translatepress-multilingual"); ?>
<?php __("Different Menu Items for each Language", "translatepress-multilingual"); ?>
<?php __("Automatic User Language Detection", "translatepress-multilingual"); ?>
<?php __("Upgrade to PRO", "translatepress-multilingual"); ?>
<?php __("Upgrade to PRO with our biggest discount of the year!", "translatepress-multilingual"); ?>
<?php __("This Black Friday, get access to these features and more at a fraction of the costs:", "translatepress-multilingual"); ?>
<?php __("No available suggestions", "translatepress-multilingual"); ?>
<?php __("Suggestions from translation memory", "translatepress-multilingual"); ?>
<?php __("Click to Copy", "translatepress-multilingual"); ?>
<?php __("Human Translation", "translatepress-multilingual"); ?>
<?php __("Machine Translation", "translatepress-multilingual"); ?>
<?php __("Gettext File Translation", "translatepress-multilingual"); ?>
<?php __("Text on this page is %s% translated into all languages.", "translatepress-multilingual"); ?>
<?php __("%1$s% of text on this page is translated into %2$s.", "translatepress-multilingual"); ?>
<?php __("This page is %1$s% translated into %2$s.", "translatepress-multilingual"); ?>
<?php __("The slug that you are trying to edit is present in other slug types:%s%. Editing it will replace each occurrence, regardless of the current type.", "translatepress-multilingual"); ?>
<?php __("Hover any text on the page, click %s,<br> then modify the translation in the sidebar.", "translatepress-multilingual"); ?>
<?php __("Don't forget to Save Translation. Use keyboard shortcut CTRL(⌘) + S", "translatepress-multilingual"); ?>
<?php __("Switch language to see the translation changes directly on the page.", "translatepress-multilingual"); ?>
<?php __("Search for any text in this page in the dropdown.", "translatepress-multilingual"); ?>
<?php __("Your %s license has <span class=\"trp-license-status-emphasized\">expired</span>.", "translatepress-multilingual"); ?>
<?php __("Please renew your license to continue receiving access to TranslatePress AI, premium addons, automatic updates and support.", "translatepress-multilingual"); ?>
<?php __("Renew Now", "translatepress-multilingual"); ?>
<?php __("<strong>This Black Friday, renew your license at a special price</strong> to continue receiving access to product downloads, automatic updates, and support.", "translatepress-multilingual"); ?>
<?php __("Get Deal", "translatepress-multilingual"); ?>
<?php __("Your %s license was <span class=\"trp-license-status-emphasized\">refunded</span>.", "translatepress-multilingual"); ?>
<?php __("Please purchase a new license to continue receiving access to TranslatePress AI, premium addons, automatic updates and support.", "translatepress-multilingual"); ?>
<?php __("Purchase a new license", "translatepress-multilingual"); ?>
<?php __("Your %s license is <span class=\"trp-license-status-emphasized\">missing or invalid</span>.", "translatepress-multilingual"); ?>
<?php __("Please enter a valid license to get access to TranslatePress AI, premium addons, automatic updates and support. Need a license key? %1$sPurchase one now%2$s", "translatepress-multilingual"); ?>
<?php __("Enter a valid license", "translatepress-multilingual"); ?>
<?php __("Slugs", "translatepress-multilingual"); ?>
<?php __("Meta Information", "translatepress-multilingual"); ?>
<?php __("String List", "translatepress-multilingual"); ?>
<?php __("Gettext Strings", "translatepress-multilingual"); ?>
<?php __("Images", "translatepress-multilingual"); ?>
<?php __("Videos", "translatepress-multilingual"); ?>
<?php __("Audios", "translatepress-multilingual"); ?>
<?php __("Dynamically Added Strings", "translatepress-multilingual"); ?>
<?php __("Translation Editor", "translatepress-multilingual"); ?>
<?php __("Edit translations by visually selecting them on each site page", "translatepress-multilingual"); ?>
<?php __("String Translation", "translatepress-multilingual"); ?>
<?php __("Edit url slug translations, plugins and theme translation (emails, forms etc.)", "translatepress-multilingual"); ?>
<?php __("Current User", "translatepress-multilingual"); ?>
<?php __("Logged Out", "translatepress-multilingual"); ?>
<?php __("Translate Page", "translatepress-multilingual"); ?>
<?php __("Add a New Language", "translatepress-multilingual"); ?>
<?php __("Your License is Invalid", "translatepress-multilingual"); ?>
<?php __("Get More AI Words (%d left)", "translatepress-multilingual"); ?>
<?php __("Opens post in the translation editor. Post must be saved as draft or published beforehand.", "translatepress-multilingual"); ?>
<?php __("Security check", "translatepress-multilingual"); ?>
<?php __("<strong>Warning:</strong> Some strings have possibly incorrectly encoded characters. This may result in breaking the queries, rendering the page untranslated in live mode. Consider revising the following strings or their method of outputting.", "translatepress-multilingual"); ?>
<?php __("IMPORTANT: It is strongly recommended to first backup the database!", "translatepress-multilingual"); ?>
<?php __("Are you sure you want to continue?", "translatepress-multilingual"); ?>
<?php __("TranslatePress data update", "translatepress-multilingual"); ?>
<?php __("We need to update your translations database to the latest version.", "translatepress-multilingual"); ?>
<?php __("Updating will allow editing translations of localized text from plugins and theme. Existing translation will still work as expected.", "translatepress-multilingual"); ?>
<?php __("Run the updater", "translatepress-multilingual"); ?>
<?php __("Updating will allow editing translations of slugs. Existing translation will still work as expected.", "translatepress-multilingual"); ?>
<?php __("Please activate the SEO Addon from <br/>WordPress -> Settings -> TranslatePress -> Addons section", "translatepress-multilingual"); ?>
<?php __("Go to Addons", "translatepress-multilingual"); ?>
<?php __("The SEO Pack add-on allows translation of all the URL slugs:", "translatepress-multilingual"); ?>
<?php __("Taxonomy slugs", "translatepress-multilingual"); ?>
<?php __("Term slugs", "translatepress-multilingual"); ?>
<?php __("Post slugs (this includes pages and custom post types)", "translatepress-multilingual"); ?>
<?php __("Post type base slugs", "translatepress-multilingual"); ?>
<?php __("WooCommerce slugs", "translatepress-multilingual"); ?>
<?php __("The SEO Pack add-on is available with ALL premium versions of the plugin.", "translatepress-multilingual"); ?>
<?php __("Upgrade to Pro", "translatepress-multilingual"); ?>
<?php __("Description", "translatepress-multilingual"); ?>
<?php __("Article Section", "translatepress-multilingual"); ?>
<?php __("Article Tag", "translatepress-multilingual"); ?>
<?php __("OG Title", "translatepress-multilingual"); ?>
<?php __("OG Site Name", "translatepress-multilingual"); ?>
<?php __("OG Description", "translatepress-multilingual"); ?>
<?php __("OG Image Alt", "translatepress-multilingual"); ?>
<?php __("Twitter Title", "translatepress-multilingual"); ?>
<?php __("Twitter Description", "translatepress-multilingual"); ?>
<?php __("Twitter Image Alt", "translatepress-multilingual"); ?>
<?php __("Page Title", "translatepress-multilingual"); ?>
<?php __("Dublin Core Title", "translatepress-multilingual"); ?>
<?php __("Dublin Core Description", "translatepress-multilingual"); ?>
<?php __("OG Image", "translatepress-multilingual"); ?>
<?php __("OG Image Secure URL", "translatepress-multilingual"); ?>
<?php __("Twitter Image", "translatepress-multilingual"); ?>
<?php __("Removing cdata dictionary strings for language %s...", "translatepress-multilingual"); ?>
<?php __("Removing untranslated dictionary links for language %s...", "translatepress-multilingual"); ?>
<?php __("Removing duplicated gettext strings for language %s...", "translatepress-multilingual"); ?>
<?php __("Removing duplicated dictionary strings for language %s...", "translatepress-multilingual"); ?>
<?php __("Removing untranslated dictionary strings where translation is available for language %s...", "translatepress-multilingual"); ?>
<?php __("Inserting original strings for language %s...", "translatepress-multilingual"); ?>
<?php __("Cleaning original strings table for language %s...", "translatepress-multilingual"); ?>
<?php __("Updating original string ids for language %s...", "translatepress-multilingual"); ?>
<?php __("Regenerating original meta table for language %s...", "translatepress-multilingual"); ?>
<?php __("Cleaning original meta table for language %s...", "translatepress-multilingual"); ?>
<?php __("Replacing original id NULL with value for language %s...", "translatepress-multilingual"); ?>
<?php __("Inserting gettext original strings for language %s...", "translatepress-multilingual"); ?>
<?php __("Cleaning gettext original strings table for language %s...", "translatepress-multilingual"); ?>
<?php __("Updating gettext original string ids for language %s...", "translatepress-multilingual"); ?>
<?php __("Starting gettext database optimization in the background...", "translatepress-multilingual"); ?>
<?php __("Migrating taxonomy and post type base slugs to new table structure...", "translatepress-multilingual"); ?>
<?php __("Migrating post slugs to new table structure for language %s...", "translatepress-multilingual"); ?>
<?php __("Migrating term slugs to new table structure for language %s...", "translatepress-multilingual"); ?>
<?php __("Finishing up...", "translatepress-multilingual"); ?>
<?php __("TranslatePress needs to optimize gettext database tables. Translations continue to work while this runs in the background.", "translatepress-multilingual"); ?>
<?php __("Before starting, we strongly recommend creating a database backup.", "translatepress-multilingual"); ?>
<?php __("Start optimization", "translatepress-multilingual"); ?>
<?php __("Update aborted! Could not schedule gettext database optimization.", "translatepress-multilingual"); ?>
<?php __("Database optimization did not complete successfully. We recommend restoring the original database or <a href=\"%s\" >trying again.</a>", "translatepress-multilingual"); ?>
<?php __("Update aborted! Your user account doesn't have the capability to perform database updates.", "translatepress-multilingual"); ?>
<?php __("Update aborted! Invalid nonce.", "translatepress-multilingual"); ?>
<?php __("Update aborted! Incorrect action.", "translatepress-multilingual"); ?>
<?php __("Update aborted! Start the gettext database optimization separately from the Advanced settings page.", "translatepress-multilingual"); ?>
<?php __("Update aborted! Incorrect language code.", "translatepress-multilingual"); ?>
<?php __("Updating database to version %s+", "translatepress-multilingual"); ?>
<?php __("Processing table for language %s...", "translatepress-multilingual"); ?>
<?php __("Back to TranslatePress Settings", "translatepress-multilingual"); ?>
<?php __("Successfully updated database!", "translatepress-multilingual"); ?>
<?php __(" done.", "translatepress-multilingual"); ?>
<?php __("Update aborted while %1$s. SQL error: %2$s", "translatepress-multilingual"); ?>
<?php __("inserting original strings", "translatepress-multilingual"); ?>
<?php __("checking original string insertion progress", "translatepress-multilingual"); ?>
<?php __("cleaning duplicate original strings", "translatepress-multilingual"); ?>
<?php __("updating original string IDs", "translatepress-multilingual"); ?>
<?php __("checking original string ID update progress", "translatepress-multilingual"); ?>
<?php __("inserting gettext original strings", "translatepress-multilingual"); ?>
<?php __("checking gettext original insertion progress", "translatepress-multilingual"); ?>
<?php __("cleaning duplicate gettext original strings", "translatepress-multilingual"); ?>
<?php __("updating gettext original string IDs", "translatepress-multilingual"); ?>
<?php __("checking gettext original string ID update progress", "translatepress-multilingual"); ?>
<?php __("All individual TranslatePress add-on plugins <a href=\"%1$s\" target=\"_blank\">have been discontinued</a> and are now included in the premium Personal, Business and Developer versions of TranslatePress. Please log into your <a href=\"%2$s\" target=\"_blank\">account page</a>, download the new premium version and install it. Your individual addons settings will be ported over.", "translatepress-multilingual"); ?>
<?php __("Brand-new Language Switcher Settings are here!", "translatepress-multilingual"); ?>
<?php __("Explore pre-made templates, switch colors, flag styles, spacing, layouts & more. Use the live preview to perfect your switcher in seconds.", "translatepress-multilingual"); ?>
<?php __("Start customizing", "translatepress-multilingual"); ?>
<?php __("Read documentation", "translatepress-multilingual"); ?>
<?php __("<strong>TranslatePress</strong> requires <strong><a href=\"http://php.net/manual/en/book.mbstring.php\">Multibyte String PHP library</a></strong>. Please contact your server administrator to install it on your server.", "translatepress-multilingual"); ?>
<?php __("Detected long query limitation on WPEngine hosting. Some large pages may appear untranslated. You can remove limitation by adding the following to your site’s wp-config.php: define( 'WPE_GOVERNOR', false ); ", "translatepress-multilingual"); ?>
<?php __("Custom Language Flag", "translatepress-multilingual"); ?>
<?php __("The Language code of the added custom language cannot be empty.", "translatepress-multilingual"); ?>
<?php __("The Language code of the added custom language is invalid.", "translatepress-multilingual"); ?>
<?php __("The Automatic Translation Code of the added custom language is invalid.", "translatepress-multilingual"); ?>
<?php __("TranslatePress AI", "translatepress-multilingual"); ?>
<?php __("Your TranslatePress AI API Key is valid.", "translatepress-multilingual"); ?>
<?php __("Your TranslatePress AI API Key is invalid.", "translatepress-multilingual"); ?>
<?php __("Your TranslatePress AI API Key has expired.", "translatepress-multilingual"); ?>
<?php __("Activate API Key", "translatepress-multilingual"); ?>
<?php __("Deactivate API Key", "translatepress-multilingual"); ?>
<?php __("Add a TranslatePress AI API Key", "translatepress-multilingual"); ?>
<?php __("TranslatePress AI API Key", "translatepress-multilingual"); ?>
<?php __("Manage your TranslatePress AI API Key in your %1$s.", "translatepress-multilingual"); ?>
<?php __("Don’t have a TranslatePress AI API Key?", "translatepress-multilingual"); ?>
<?php __("Get a free TranslatePress AI API Key Today", "translatepress-multilingual"); ?>
<?php __("Add your TranslatePress AI API Key", "translatepress-multilingual"); ?>
<?php __("Add your TranslatePress AI API Key to unlock all premium features. Find the TranslatePress AI API Key in your", "translatepress-multilingual"); ?>
<?php __("Your TranslatePress AI API Key is valid and active.", "translatepress-multilingual"); ?>
<?php __("Activate TranslatePress AI API Key", "translatepress-multilingual"); ?>
<?php __("No Active API Key Detected for this website.", "translatepress-multilingual"); ?>
<?php __("In order to enable Automatic Translation using TranslatePress AI, you need an API key by creating a free account.", "translatepress-multilingual"); ?>
<?php __("Enter your API key", "translatepress-multilingual"); ?>
<?php __("In order to enable Automatic Translation using TranslatePress AI, please enter your API key from", "translatepress-multilingual"); ?>
<?php __("API Key", "translatepress-multilingual"); ?>
<?php __("No Active TranslatePress AI API Key Detected for this website.", "translatepress-multilingual"); ?>
<?php __("Get Your Free TranslatePress AI API Key", "translatepress-multilingual"); ?>
<?php __("Generate API Key", "translatepress-multilingual"); ?>
<?php __("You have a valid %s <strong>API Key</strong>.", "translatepress-multilingual"); ?>
<?php __("Manage your API Key & quota on the %s", "translatepress-multilingual"); ?>
<?php __("Get a Free AI API Key", "translatepress-multilingual"); ?>
<?php __("This website is already activated under a free API key. Each website can only use one free API key.", "translatepress-multilingual"); ?>
<?php __("This website is already activated under a free API key. Each website can only use one free API key. Please upgrade to a premium plan for more TranslatePress AI words from %1$s your account %2$s.", "translatepress-multilingual"); ?>
<?php __("Debug Data for API Key Checking", "translatepress-multilingual"); ?>
<?php __("Debug Data for API Key Activation", "translatepress-multilingual"); ?>
<?php __("TranslatePress Add-ons", "translatepress-multilingual"); ?>
<?php __("You must first purchase this version to have access to the addon %1$shere%2$s", "translatepress-multilingual"); ?>
<?php __("Please %1$senter your license%2$s key first, to activate this addon.", "translatepress-multilingual"); ?>
<?php __("You need an active license to have access to the addon. Renew or purchase a new one %1$shere%2$s.", "translatepress-multilingual"); ?>
<?php __("Advanced Add-ons", "translatepress-multilingual"); ?>
<?php __("These addons extend your translation plugin and are available in the Developer, Business and Personal plans.", "translatepress-multilingual"); ?>
<?php __("SEO Pack", "translatepress-multilingual"); ?>
<?php __("SEO Pack (Legacy)", "translatepress-multilingual"); ?>
<?php __("SEO support for page slug, page title, description and facebook and twitter social graph information. The HTML lang attribute is properly set.", "translatepress-multilingual"); ?>
<?php __("Multiple Languages", "translatepress-multilingual"); ?>
<?php __("Add as many languages as you need for your project to go global. Publish your language only when all your translations are done.", "translatepress-multilingual"); ?>
<?php __("Pro Add-ons", "translatepress-multilingual"); ?>
<?php __("These addons extend your translation plugin and are available in the Business and Developer plans.", "translatepress-multilingual"); ?>
<?php __("DeepL Automatic Translation", "translatepress-multilingual"); ?>
<?php __("Automatically translate your website through the DeepL API.", "translatepress-multilingual"); ?>
<?php __("Prompts visitors to switch to their preferred language based on their browser settings or IP address and remembers the last visited language.", "translatepress-multilingual"); ?>
<?php __("Translator Accounts", "translatepress-multilingual"); ?>
<?php __("Create translator accounts for new users or allow existing users that are not administrators to translate your website.", "translatepress-multilingual"); ?>
<?php __("Browse As User Role", "translatepress-multilingual"); ?>
<?php __("Navigate your website just like a particular user role would. Really useful for dynamic content or hidden content that appears for particular users.", "translatepress-multilingual"); ?>
<?php __("Navigation Based on Language", "translatepress-multilingual"); ?>
<?php __("Configure different menu items for different languages.", "translatepress-multilingual"); ?>
<?php __("Different Domain per Language", "translatepress-multilingual"); ?>
<?php __("Connect separate domains or subdomains to each of your translated versions. Strengthen your brand’s local identity and boost SEO performance for every language you support.", "translatepress-multilingual"); ?>
<?php __("Recommended Plugins", "translatepress-multilingual"); ?>
<?php __("A short list of plugins you can use to extend your website.", "translatepress-multilingual"); ?>
<?php __("Profile Builder", "translatepress-multilingual"); ?>
<?php __("Capture more user information on the registration form with the help of Profile Builder's custom user profile fields and/or add an Email Confirmation process to verify your customers accounts.", "translatepress-multilingual"); ?>
<?php __("Paid Member Subscriptions", "translatepress-multilingual"); ?>
<?php __("Accept user payments, create subscription plans and restrict content on your membership site.", "translatepress-multilingual"); ?>
<?php __("WP Webhooks Automator", "translatepress-multilingual"); ?>
<?php __("Create no-code automations and workflows on your WordPress site. Easily connect your plugins, sites and apps together.", "translatepress-multilingual"); ?>
<?php __("Save Changes", "translatepress-multilingual"); ?>
<?php __("Account Page", "translatepress-multilingual"); ?>
<?php __("You can get one for %1$sfree%2$s, by creating a free account. It includes:", "translatepress-multilingual"); ?>
<?php __("Access to TranslatePress AI for instant automatic translations", "translatepress-multilingual"); ?>
<?php __("2000 AI words to translate automatically", "translatepress-multilingual"); ?>
<?php __("Debug Information", "translatepress-multilingual"); ?>
<?php __("Get more AI words and unlock all features with TranslatePress Pro.", "translatepress-multilingual"); ?>
<?php __("Upgrade now ↗", "translatepress-multilingual"); ?>
<?php __("Already purchased a Premium version?", "translatepress-multilingual"); ?>
<?php __("Go to your %1$s", "translatepress-multilingual"); ?>
<?php __("TranslatePress.com Account", "translatepress-multilingual"); ?>
<?php __("Download & Install the Pro plugin", "translatepress-multilingual"); ?>
<?php __("Learn More", "translatepress-multilingual"); ?>
<?php __("TranslatePress Errors", "translatepress-multilingual"); ?>
<?php __("There are no logged errors.", "translatepress-multilingual"); ?>
<?php __("Change language", "translatepress-multilingual"); ?>
<?php __("Website language selector", "translatepress-multilingual"); ?>
<?php __("WordPress Translation Plugin", "translatepress-multilingual"); ?>
<?php __("Available languages", "translatepress-multilingual"); ?>
<?php __("Back to Glossary", "translatepress-multilingual"); ?>
<?php __("Search Existing Translations", "translatepress-multilingual"); ?>
<?php __("Search the existing dictionary entries to see how a term is currently translated in each language.", "translatepress-multilingual"); ?>
<?php __("To fully explore all the translations, use %s.", "translatepress-multilingual"); ?>
<?php __("Search existing translations", "translatepress-multilingual"); ?>
<?php __("Search", "translatepress-multilingual"); ?>
<?php __("Replace Existing Translations", "translatepress-multilingual"); ?>
<?php __("For each language, enter the current (existing) translation you want to find; every case-insensitive occurrence in the stored translations will be replaced with the new translation, keeping the original capitalization.", "translatepress-multilingual"); ?>
<?php __("Leaving a language field empty will skip that language entirely (no changes will be made for it). Only one existing translation per language can be entered at a time. If you have multiple translations to replace for the same language, simply run the replacement again with the next value.", "translatepress-multilingual"); ?>
<?php __("The \"Existing translation\" is not the term in the default language, but rather the already existing wrong translation you want to correct.", "translatepress-multilingual"); ?>
<?php __("Language", "translatepress-multilingual"); ?>
<?php __("Existing translation", "translatepress-multilingual"); ?>
<?php __("New translation", "translatepress-multilingual"); ?>
<?php __("Replace in existing translations", "translatepress-multilingual"); ?>
<?php __("Cancel", "translatepress-multilingual"); ?>
<?php __("The requested glossary term could not be found. It may have been deleted.", "translatepress-multilingual"); ?>
<?php __("&laquo; Back to Glossary", "translatepress-multilingual"); ?>
<?php __("Glossary is available only with the TranslatePress AI engine.", "translatepress-multilingual"); ?>
<?php __("Select the %s automatic translation engine to add and manage glossary terms. For other translation engines (such as DeepL or Google Translate), glossary functions are available in the translation provider’s dashboard.", "translatepress-multilingual"); ?>
<?php __("Add Glossary Term", "translatepress-multilingual"); ?>
<?php __("Define words or phrases that should not be translated automatically, and optionally provide replacements per language.", "translatepress-multilingual"); ?>
<?php __("Term (%s)", "translatepress-multilingual"); ?>
<?php __("The original word or phrase in the default language.", "translatepress-multilingual"); ?>
<?php __("Add Term", "translatepress-multilingual"); ?>
<?php __("Search glossary terms", "translatepress-multilingual"); ?>
<?php __("Search terms", "translatepress-multilingual"); ?>
<?php __("Search Glossary", "translatepress-multilingual"); ?>
<?php __("Translations", "translatepress-multilingual"); ?>
<?php __("Loading…", "translatepress-multilingual"); ?>
<?php __("To edit existing translations, use the %s.", "translatepress-multilingual"); ?>
<?php __("search & replace tool", "translatepress-multilingual"); ?>
<?php __("Language Switcher update notice", "translatepress-multilingual"); ?>
<?php __("Legacy language switcher is currently enabled", "translatepress-multilingual"); ?>
<?php __("We’ve upgraded the switcher for richer customization and a better user experience.<br>In order to use the new configurator, turn off <strong>Load legacy language switcher</strong>.", "translatepress-multilingual"); ?>
<?php __("Note: You can switch back anytime from <strong>Advanced Settings → <a href=\"%s\">Troubleshooting</a></strong>.", "translatepress-multilingual"); ?>
<?php __("Enable the new switcher", "translatepress-multilingual"); ?>
<?php __("Get a translation volume estimate with a detailed breakdown per page", "translatepress-multilingual"); ?>
<?php __("Find how many translatable words are on your website", "translatepress-multilingual"); ?>
<?php __("To use <strong>DeepL</strong> for automatic translation, activate this Pro add-on from the <a href=\"%1$s\" target=\"_self\" title=\"%2$s\">%2$s</a>.", "translatepress-multilingual"); ?>
<?php __("<strong>DeepL</strong> automatic translation is available as a <a href=\"%1$s\" target=\"_blank\" title=\"%2$s\">%2$s</a>.", "translatepress-multilingual"); ?>
<?php __("By upgrading you'll get access to all paid add-ons, premium support and help fund the future development of TranslatePress.", "translatepress-multilingual"); ?>
<?php __("TranslatePress Pro Add-on", "translatepress-multilingual"); ?>
<?php __("Addons tab", "translatepress-multilingual"); ?>
<?php __("Please note that DeepL API usage is paid separately. See <a href=\"https://www.deepl.com/pro.html#developer\">DeepL pricing information</a>.", "translatepress-multilingual"); ?>
<?php __("TranslatePress Pro Add-ons", "translatepress-multilingual"); ?>
<?php __("Test API credentials", "translatepress-multilingual"); ?>
<?php __("Check if the selected translation engine is configured correctly.", "translatepress-multilingual"); ?>
<?php __("Alternative Engines", "translatepress-multilingual"); ?>
<?php __("Switch to TranslatePress AI", "translatepress-multilingual"); ?>
<?php __("Integrate machine translation directly with your WordPress website.", "translatepress-multilingual"); ?>
<?php __("More info", "translatepress-multilingual"); ?>
<?php __("Choose which engine you want to use in order to %1$s automatically translate your website.", "translatepress-multilingual"); ?>
<?php __("Automatically Translate Slugs", "translatepress-multilingual"); ?>
<?php __("Generate automatic translations of slugs for posts, pages and Custom Post Types.<br/>The slugs will be automatically translated starting with the second refresh of each page.", "translatepress-multilingual"); ?>
<?php __("This feature is only available in the paid version. Upgrade TranslatePress and unlock more premium features.", "translatepress-multilingual"); ?>
<?php __("Requires <a href=\"%s\" title=\"TranslatePress Add-on SEO Pack documentation\" target=\"_blank\">SEO Pack Add-on</a> to be installed and activated.", "translatepress-multilingual"); ?>
<?php __("Upgrade now", "translatepress-multilingual"); ?>
<?php __("Automatic Translation Settings", "translatepress-multilingual"); ?>
<?php __("AI Words Low Notification", "translatepress-multilingual"); ?>
<?php __("Receive an email notification when your TranslatePress AI word count drops below the specified threshold.", "translatepress-multilingual"); ?>
<?php __("This feature is only available when using the TranslatePress AI translation engine.", "translatepress-multilingual"); ?>
<?php __("Notification Email", "translatepress-multilingual"); ?>
<?php __("The email address where the low AI words notification will be sent.", "translatepress-multilingual"); ?>
<?php __("Word Threshold", "translatepress-multilingual"); ?>
<?php __("words", "translatepress-multilingual"); ?>
<?php __("You will be notified when remaining AI words drop below this number.", "translatepress-multilingual"); ?>
<?php __("Block Crawlers", "translatepress-multilingual"); ?>
<?php __("Block crawlers from triggering automatic translations on your website.<br>This will not prevent crawlers from accessing this site's pages.", "translatepress-multilingual"); ?>
<?php __("Limit machine translation / characters per day", "translatepress-multilingual"); ?>
<?php __("Add a limit to the number of automatically translated characters so you can better budget your project.", "translatepress-multilingual"); ?>
<?php __("characters per day", "translatepress-multilingual"); ?>
<?php __("Today's Character Count: ", "translatepress-multilingual"); ?>
<?php __("Log machine translation queries.", "translatepress-multilingual"); ?>
<?php __("Only enable for testing purposes. Can impact performance.<br>All records are stored in the wp_trp_machine_translation_log database table. Use a plugin like <a href=\"https://wordpress.org/plugins/wp-data-access/\" target=\"_blank\">WP Data Access</a> to browse the logs or directly from your database manager (PHPMyAdmin, etc.)", "translatepress-multilingual"); ?>
<?php __("Test API Credentials", "translatepress-multilingual"); ?>
<?php __("HTTP Referrer: ", "translatepress-multilingual"); ?>
<?php __("Use this HTTP Referrer if the API lets you restrict key usage from its Dashboard.", "translatepress-multilingual"); ?>
<?php __("Request URL", "translatepress-multilingual"); ?>
<?php __("Request Headers", "translatepress-multilingual"); ?>
<?php __("Request Body", "translatepress-multilingual"); ?>
<?php __("Response", "translatepress-multilingual"); ?>
<?php __("Response Body", "translatepress-multilingual"); ?>
<?php __("Entire Response From wp_remote_get():", "translatepress-multilingual"); ?>
<?php __("All Languages", "translatepress-multilingual"); ?>
<?php __("Select the languages you wish to make your website available in.", "translatepress-multilingual"); ?>
<?php __("Formality", "translatepress-multilingual"); ?>
<?php __("Code", "translatepress-multilingual"); ?>
<?php __("Slug", "translatepress-multilingual"); ?>
<?php __("Default", "translatepress-multilingual"); ?>
<?php __("Formal", "translatepress-multilingual"); ?>
<?php __("Informal", "translatepress-multilingual"); ?>
<?php __("This language does not support formality. ", "translatepress-multilingual"); ?>
<?php __("Are you sure you want to remove this language?", "translatepress-multilingual"); ?>
<?php __("Custom Languages", "translatepress-multilingual"); ?>
<?php __("To Add more languages activate the Multiple Languages Addon", "translatepress-multilingual"); ?>
<?php __("You need an active license to add more languages. Verify in your %1$saccount%2$s that your license is valid", "translatepress-multilingual"); ?>
<?php __("Please %1$senter your license%2$s key first to add more languages.", "translatepress-multilingual"); ?>
<?php __("Adding more than two languages is a paid feature. Upgrade TranslatePress and unlock more premium features.", "translatepress-multilingual"); ?>
<?php __("Website Languages", "translatepress-multilingual"); ?>
<?php __("Default Language", "translatepress-multilingual"); ?>
<?php __("Select the language your content is written in.", "translatepress-multilingual"); ?>
<?php __("WARNING. Changing the default language will invalidate existing translations.", "translatepress-multilingual"); ?>
<?php __("Even changing from en_US to en_GB, because they are treated as two different languages.", "translatepress-multilingual"); ?>
<?php __("In most cases changing the default flag is all it is needed: ", "translatepress-multilingual"); ?>
<?php __("replace the default flag", "translatepress-multilingual"); ?>
<?php __("Re-run Setup Wizard", "translatepress-multilingual"); ?>
<?php __("The Setup wizard allows you to quickly setup TranslatePress. You can initiate it at any time.", "translatepress-multilingual"); ?>
<?php __("Language Settings", "translatepress-multilingual"); ?>
<?php __("Use Native language name", "translatepress-multilingual"); ?>
<?php __("Check if you want to display languages in their native names. Otherwise, languages will be displayed in English.", "translatepress-multilingual"); ?>
<?php __("Use a subdirectory for the default language", "translatepress-multilingual"); ?>
<?php __("Check if you want to add the subdirectory in the URL for the default language.</br>By checking this option, the default language seen by website visitors will become the first one in the \"All Languages\" list.", "translatepress-multilingual"); ?>
<?php __("Force language in custom links", "translatepress-multilingual"); ?>
<?php __("Select Yes if you want to force custom links without language encoding to keep the currently selected language.", "translatepress-multilingual"); ?>
<?php __("Shortcode ", "translatepress-multilingual"); ?>
<?php __("Use shortcode on any page or widget.", "translatepress-multilingual"); ?>
<?php __("You can also add the <a href=\"%s\" title=\"Language Switcher Block Documentation\">Language Switcher Block</a> in the WP Gutenberg Editor.", "translatepress-multilingual"); ?>
<?php __("Menu item", "translatepress-multilingual"); ?>
<?php __("Go to  %1$s Appearance -> Menus%2$s to add languages to the Language Switcher in any menu.", "translatepress-multilingual"); ?>
<?php __("Learn more in our documentation.", "translatepress-multilingual"); ?>
<?php __("Floating language selection", "translatepress-multilingual"); ?>
<?php __("Add a floating dropdown that follows the user on every page.", "translatepress-multilingual"); ?>
<?php __("Show \"Powered by TranslatePress\"", "translatepress-multilingual"); ?>
<?php __("Show the small \"Powered by TranslatePress\" label in the floater language switcher.", "translatepress-multilingual"); ?>
<?php __("5 Days to Better Multilingual Websites", "translatepress-multilingual"); ?>
<?php __("%sJoin our FREE & EXCLUSIVE onboarding course%s and learn how to grow your multilingual traffic, reach international markets, and save time & money while getting the most out of TranslatePress!", "translatepress-multilingual"); ?>
<?php __("Invalid email address", "translatepress-multilingual"); ?>
<?php __("Your email", "translatepress-multilingual"); ?>
<?php __("Sign me up!", "translatepress-multilingual"); ?>
<?php __("Sign up with your email address and receive a 5-part email guide to help you maximize the power of TranslatePress.", "translatepress-multilingual"); ?>
<?php __("Dismiss email course notification", "translatepress-multilingual"); ?>
<?php __("Hey %s,<br>Never miss an important update - opt in to our security and feature updates notifications, and non-sensitive diagnostic tracking.", "translatepress-multilingual"); ?>
<?php __("Allow & Continue", "translatepress-multilingual"); ?>
<?php __("Skip", "translatepress-multilingual"); ?>
<?php __("This will allow TranslatePress to:", "translatepress-multilingual"); ?>
<?php __("Your profile overview", "translatepress-multilingual"); ?>
<?php __("Name and email address", "translatepress-multilingual"); ?>
<?php __("Admin Notices", "translatepress-multilingual"); ?>
<?php __("Updates, announcements, marketing, no spam", "translatepress-multilingual"); ?>
<?php __("Plugin status & settings", "translatepress-multilingual"); ?>
<?php __("Active, Deactivated, installed version and settings", "translatepress-multilingual"); ?>
<?php __("Privacy Policy", "translatepress-multilingual"); ?>
<?php __("Terms of Service", "translatepress-multilingual"); ?>
<?php __("Support", "translatepress-multilingual"); ?>
<?php __("Documentation", "translatepress-multilingual"); ?>
<?php __("Add Extra AI Words", "translatepress-multilingual"); ?>
<?php __("Optimize TranslatePress database tables", "translatepress-multilingual"); ?>
<?php __("<strong>IMPORTANT NOTE:</strong> Before performing this action it is strongly recommended to first backup the database.", "translatepress-multilingual"); ?>
<?php __("IMPORTANT: It is strongly recommended to first backup the database!! Are you sure you want to continue?", "translatepress-multilingual"); ?>
<?php __("Operations to perform", "translatepress-multilingual"); ?>
<?php __("Remove CDATA for original and dictionary strings", "translatepress-multilingual"); ?>
<?php __("Removes CDATA from trp_original_strings and trp_dictionary_* tables.<br>This type of content should not be detected by TranslatePress. It might have been introduced in the database in older versions of the plugin.", "translatepress-multilingual"); ?>
<?php __("Remove untranslated links from dictionary tables", "translatepress-multilingual"); ?>
<?php __("Removes untranslated links and images from all trp_dictionary_* tables. These tables contain translations for user-inputted strings such as post content, post title, menus etc.", "translatepress-multilingual"); ?>
<?php __("Remove duplicate rows for gettext strings", "translatepress-multilingual"); ?>
<?php __("Cleans up all trp_gettext_* tables of duplicate rows. These tables contain translations for themes and plugin strings.", "translatepress-multilingual"); ?>
<?php __("Remove duplicate rows for dictionary strings", "translatepress-multilingual"); ?>
<?php __("Cleans up all trp_dictionary_* tables of duplicate rows. These tables contain translations for user-inputted strings such as post content, post title, menus etc.", "translatepress-multilingual"); ?>
<?php __("Remove duplicate rows for original dictionary strings", "translatepress-multilingual"); ?>
<?php __("Cleans up all trp_original_strings table of duplicate rows. This table contains strings in the default language, without any translation.<br>The trp_original_meta table, which contains meta information that refers to the post parent’s ID, is also regenerated.<br>Such duplicates can appear in exceptional situations of unexpected behavior.", "translatepress-multilingual"); ?>
<?php __("Replace gettext strings that have original ID NULL with the correct original IDs", "translatepress-multilingual"); ?>
<?php __("Fixes an edge case issue where some gettext strings have the original ID incorrectly set to NULL, causing problems in the Translation Editor.<br>This operation corrects the original IDs in the trp_gettext_* tables.<br>Only check this option if you encountered an issue in the Translation Editor where clicking the green pencil did not bring up the gettext string for translation in the left sidebar.<br>Otherwise, please leave this option unchecked because it's an intensive operation.", "translatepress-multilingual"); ?>
<?php __("Optimize Database", "translatepress-multilingual"); ?>
<?php __("TranslatePress Database Updater", "translatepress-multilingual"); ?>
<?php __("Updating TranslatePress tables. Please leave this window open.", "translatepress-multilingual"); ?>
<?php __("The inactive languages will still be visible and active for the admin. For other users they won't be visible in the language switchers and won't be accessible either.", "translatepress-multilingual"); ?>
<?php __("unknown", "translatepress-multilingual"); ?>
<?php __("<strong>Extra Languages add-on</strong> requires TranslatePress version %1$s or higher. You are currently using version %2$s. Please update TranslatePress to enable this feature.", "translatepress-multilingual"); ?>
<?php __("Automatic and manual slug translation changes performed when <strong>TranslatePress - Multilingual</strong> 2.8.4 was active had to be removed because of some issues with that version. All slug translations from before that version are now in use. Thank you for understanding!", "translatepress-multilingual"); ?>
<?php __("If you absolutely need them, the removed translations can be found in tables trp_slug_original_obsolete and trp_slug_translation_obsolete.", "translatepress-multilingual"); ?>
<?php __("View Docs", "translatepress-multilingual"); ?>
<?php __("Assign different domains or subdomains to each language. When visitors access these domains, TranslatePress loads the appropriate language translation directly without redirecting.", "translatepress-multilingual"); ?>
<?php __("Example: %1$s for English, %2$s for Spanish, %3$s for French.", "translatepress-multilingual"); ?>
<?php __("Before enabling:", "translatepress-multilingual"); ?>
<?php __("Ensure your domains are registered, pointed to your server, and have SSL certificates configured.", "translatepress-multilingual"); ?>
<?php __("Domain", "translatepress-multilingual"); ?>
<?php __("Map this language to a different domain or sub-domain.", "translatepress-multilingual"); ?>
<?php __("https://example.com", "translatepress-multilingual"); ?>
<?php __("Prefill with current domain", "translatepress-multilingual"); ?>
<?php __("Check DNS", "translatepress-multilingual"); ?>
<?php __("Checking DNS...", "translatepress-multilingual"); ?>
<?php __("DNS is correctly configured!", "translatepress-multilingual"); ?>
<?php __("DNS check failed. Please verify your domain configuration.", "translatepress-multilingual"); ?>
<?php __("This domain is already assigned to another language.", "translatepress-multilingual"); ?>
<?php __("<strong>Different Domain per Language add-on</strong> requires TranslatePress version %1$s or higher. You are currently using version %2$s. Please update TranslatePress to enable this feature.", "translatepress-multilingual"); ?>
<?php __("Note: This option is disabled when Different Domain for Language addon is active.", "translatepress-multilingual"); ?>
<?php __("Different Domain per Language: Domain is required when domain mapping is enabled. The toggle has been disabled for languages with empty domains.", "translatepress-multilingual"); ?>
<?php __("Different Domain per Language: The same domain cannot be assigned to multiple languages. The toggle has been disabled for duplicate domains.", "translatepress-multilingual"); ?>
<?php __("Different Domain per Language: A language domain cannot be the same as the main site URL. The toggle has been disabled for the matching domain.", "translatepress-multilingual"); ?>
<?php __("Please enter a domain.", "translatepress-multilingual"); ?>
<?php __("Invalid domain format.", "translatepress-multilingual"); ?>
<?php __("Could not reach domain: %s", "translatepress-multilingual"); ?>
<?php __("Domain returned HTTP status %d.", "translatepress-multilingual"); ?>
<?php __("Domain is reachable!", "translatepress-multilingual"); ?>
<?php __("Limit this menu item to the following languages", "translatepress-multilingual"); ?>
<?php __("Date format", "translatepress-multilingual"); ?>
<?php __("Customize the date formatting per each translated language.<br/>Leave empty for default WP setting or see more information <a href=\"https://wordpress.org/support/article/formatting-date-and-time/\" title=\"Formatting Date and Time\" target=\"_blank\">here</a>", "translatepress-multilingual"); ?>
<?php __("To edit an existing TranslatePress language, input the language code and fill in only the columns you want to overwrite (e.g. Language name, Flag).<br>You can also add new custom languages. They will be available under General settings, All Languages list, where the URL slug can be edited.", "translatepress-multilingual"); ?>
<?php __("For custom flag, first upload the image in media library then paste the URL.<br>Changing or deleting a custom language will impact translations and site URL's.<br>The Language code and the ISO Code should contain only alphabetical values, numerical values, \"-\" and \"_\".<br>The ISO Codes can be found on <a href = \"https://cloud.google.com/translate/docs/languages\" target = \"_blank\">Google ISO Codes</a> and <a href = \"https://www.deepl.com/docs-api/translating-text/\" target = \"_blank\">DeepL Target Codes</a>.", "translatepress-multilingual"); ?>
<?php __("Language code", "translatepress-multilingual"); ?>
<?php __("Language name", "translatepress-multilingual"); ?>
<?php __("Native name", "translatepress-multilingual"); ?>
<?php __("ISO Code", "translatepress-multilingual"); ?>
<?php __("Flag URL", "translatepress-multilingual"); ?>
<?php __("Text RTL", "translatepress-multilingual"); ?>
<?php __("Custom language", "translatepress-multilingual"); ?>
<?php __("Disable bundled plugin translations", "translatepress-multilingual"); ?>
<?php __("By default, TranslatePress ships its own translation files in <code>wp-content/plugins/translatepress/languages/</code> and forces WordPress to use them instead of the language packs installed automatically from translate.wordpress.org.<br/>Enable this option to disable that override. WordPress will then load the community language pack from <code>wp-content/languages/plugins/</code> (if present) and fall back to the bundled files only when no pack is available.", "translatepress-multilingual"); ?>
<?php __("Disable dynamic translation", "translatepress-multilingual"); ?>
<?php __("It disables detection of strings displayed dynamically using JavaScript. <br/>Strings loaded via a server side AJAX call will still be translated.", "translatepress-multilingual"); ?>
<?php __("Disable translation for gettext strings", "translatepress-multilingual"); ?>
<?php __("Gettext Strings are strings outputted by themes and plugins. <br> Translating these types of strings through TranslatePress can be unnecessary if they are already translated using the .po/.mo translation file system.<br>Enabling this option can improve the page load performance of your site in certain cases. The disadvantage is that you can no longer edit gettext translations using TranslatePress, nor benefit from automatic translation on these strings.", "translatepress-multilingual"); ?>
<?php __("Gettext Strings translation is disabled", "translatepress-multilingual"); ?>
<?php __("To enable it go to ", "translatepress-multilingual"); ?>
<?php __("TranslatePress->Advanced Settings->Debug->Disable translation for gettext strings", "translatepress-multilingual"); ?>
<?php __(" and uncheck the Checkbox.", "translatepress-multilingual"); ?>
<?php __("Dismiss", "translatepress-multilingual"); ?>
<?php __("Exclude translated links from sitemap", "translatepress-multilingual"); ?>
<?php __("Do not include translated links in sitemaps generated by SEO plugins.<br/>Requires <a href=\"https://translatepress.com/docs/addons/seo-pack/?utm_source=tp-advanced&utm_medium=client-site&utm_campaign=miscellaneous\" title=\"TranslatePress Add-on SEO Pack documentation\" target=\"_blank\"> SEO Pack Add-on</a> to be installed and activated.", "translatepress-multilingual"); ?>
<?php __("Disable post container tags for post title", "translatepress-multilingual"); ?>
<?php __("It disables search indexing the post title in translated languages.<br/>Useful when the title of the post doesn't allow HTML thus breaking the page.", "translatepress-multilingual"); ?>
<?php __("Disable post container tags for post content", "translatepress-multilingual"); ?>
<?php __("It disables search indexing the post content in translated languages.<br/>Useful when the content of the post doesn't allow HTML thus breaking the page.", "translatepress-multilingual"); ?>
<?php __("Do not translate certain paths", "translatepress-multilingual"); ?>
<?php __("Choose what paths can be translated. Supports wildcard at the end of the path.<br>For example, to exclude https://example.com/some/path you can either use the rule /some/path/ or /some/*.<br>Enter each rule on it's own line. To exclude the home page use {{home}}.", "translatepress-multilingual"); ?>
<?php __("Exclude Paths From Translation", "translatepress-multilingual"); ?>
<?php __("Translate Only Certain Paths", "translatepress-multilingual"); ?>
<?php __("Enable the hreflang x-default tag for language:", "translatepress-multilingual"); ?>
<?php __("Enables the hreflang=\"x-default\" for an entire language. See documentation for more details.", "translatepress-multilingual"); ?>
<?php __("Translate numbers and numerals", "translatepress-multilingual"); ?>
<?php __("Enable translation of numbers ( e.g. phone numbers)", "translatepress-multilingual"); ?>
<?php __("Selector", "translatepress-multilingual"); ?>
<?php __("Exclude from dynamic translation", "translatepress-multilingual"); ?>
<?php __("Do not dynamically translate strings that are found in html nodes matching these selectors.<br>Excludes all the children of HTML nodes matching these selectors from being translated using JavaScript.<br/>These strings will still be translated on the server side if possible.", "translatepress-multilingual"); ?>
<?php __("Gettext String", "translatepress-multilingual"); ?>
<?php __("Exclude Gettext Strings", "translatepress-multilingual"); ?>
<?php __("Exclude these strings from being translated as Gettext strings by TranslatePress. Leave the domain empty to take into account any Gettext string.<br/>Can still be translated through po/mo files.", "translatepress-multilingual"); ?>
<?php __("Exclude selectors only from automatic translation", "translatepress-multilingual"); ?>
<?php __("Do not automatically translate strings that are found in html nodes matching these selectors.<br>Excludes all the children of HTML nodes matching these selectors from being automatically translated.<br>Manual translation of these strings is still possible.", "translatepress-multilingual"); ?>
<?php __("Exclude selectors from translation", "translatepress-multilingual"); ?>
<?php __("Do not translate strings that are found in html nodes matching these selectors.<br>Excludes all the children of HTML nodes matching these selectors from being translated.<br>These strings cannot be translated manually nor automatically.", "translatepress-multilingual"); ?>
<?php __("String", "translatepress-multilingual"); ?>
<?php __("Exclude strings from automatic translation", "translatepress-multilingual"); ?>
<?php __("Do not automatically translate these strings (ex. names, technical words...)<br>Paragraphs containing these strings will still be translated except for the specified part.", "translatepress-multilingual"); ?>
<?php __("Fix broken HTML", "translatepress-multilingual"); ?>
<?php __("General attempt to fix broken or missing HTML on translated pages.<br/>", "translatepress-multilingual"); ?>
<?php __("Force slash at end of home url:", "translatepress-multilingual"); ?>
<?php __("Ads a slash at the end of the home_url() function", "translatepress-multilingual"); ?>
<?php __("Show Both (recommended)", "translatepress-multilingual"); ?>
<?php __("Remove Country Locale", "translatepress-multilingual"); ?>
<?php __("Remove Region Independent Locale", "translatepress-multilingual"); ?>
<?php __("Remove duplicate hreflang", "translatepress-multilingual"); ?>
<?php __("Choose which hreflang tags will appear on your website.<br/>We recommend showing both types of hreflang tags as indicated by <a href=\"https://developers.google.com/search/docs/advanced/crawling/localized-versions\" title=\"Google Crawling\" target=\"_blank\">Google documentation</a>.<br/>Removing Country Locale when having multiple Country Locales of the same language (ex. English UK and English US) will result in showing one hreflang tag with link to just one of the region locales for that language.", "translatepress-multilingual"); ?>
<?php __("Default (example: en-US, fr-CA, etc.)", "translatepress-multilingual"); ?>
<?php __("Regional (example: en, fr, es, etc.)", "translatepress-multilingual"); ?>
<?php __("HTML Lang Attribute Format", "translatepress-multilingual"); ?>
<?php __("Change lang attribute of the html tag to a format that includes country regional or not. <br>In HTML, the lang attribute (<html lang=\"en-US\">)  should be used to  specify the language of text content so that the  browser can correctly display or process  your content (eg. for  hyphenation, styling, spell checking, etc).", "translatepress-multilingual"); ?>
<?php __("Load legacy Language Switcher", "translatepress-multilingual"); ?>
<?php __("Applies to all types of language switchers (floating, shortcode, and menu). When enabled, the site will revert to using the original Language Switcher configured in the General Settings tab, replacing the new customizable version. Your existing switcher settings will remain saved, but they will be ignored while this option is active.", "translatepress-multilingual"); ?>
<?php __("Load legacy SEO Pack Add-On", "translatepress-multilingual"); ?>
<?php __("In case the recent migration to the new slug rewrite is causing trouble, set this to Yes to use the old method <br> Please <a href=\"https://translatepress.com/support/open-ticket/?utm_source=tp-advanced&utm_medium=client-site&utm_campaign=troubleshooting\" target=\"_blank\">open a support ticket</a> letting us know of the issues you are having.", "translatepress-multilingual"); ?>
<?php __("Manual Translation Only", "translatepress-multilingual"); ?>
<?php __("TranslatePress pro-actively scans and saves strings in the database when users access translated pages. <br>This setting disables this functionality and only allows translation and string saving when inside the Translation Editor. <br>Also disables machine translation outside the Translation Editor, giving you better control over character spending, by translating only the pages you visit in the Translation Editor.", "translatepress-multilingual"); ?>
<?php __("Open language switcher only on click", "translatepress-multilingual"); ?>
<?php __("Open the language switcher shortcode by clicking on it instead of hovering.<br> Close it by clicking on it, anywhere else on the screen or by pressing the escape key. This will affect only the shortcode language switcher.", "translatepress-multilingual"); ?>
<?php __("Show opposite language in the language switcher", "translatepress-multilingual"); ?>
<?php __("Transforms the language switcher into a button showing the other available language, not the current one.<br> Only works when there are exactly two languages, the default one and a translation one.<br>This will affect the shortcode language switcher and floating language switcher as well.<br> To achieve this in menu language switcher go to Appearance->Menus->Language Switcher and select Opposite Language.", "translatepress-multilingual"); ?>
<?php __("TranslatePress needs to optimize its gettext database tables. Back up the database, then <a href=\"%s\">start the optimization</a>.", "translatepress-multilingual"); ?>
<?php __("TranslatePress gettext database optimization failed.", "translatepress-multilingual"); ?>
<?php __("Retry", "translatepress-multilingual"); ?>
<?php __("Pending gettext database optimization", "translatepress-multilingual"); ?>
<?php __("<a href=\"%s\">Click here</a> to access the database optimization tool.", "translatepress-multilingual"); ?>
<?php __("It helps remove possible duplicate translations, clear unnecessary data and repair possible metadata issues.", "translatepress-multilingual"); ?>
<?php __("<a href=\"%s\" target=\"_blank\">Here</a> you can observe the last 5 SQL errors relevant to TranslatePress if they exist.", "translatepress-multilingual"); ?>
<?php __("Troubleshooting", "translatepress-multilingual"); ?>
<?php __("Exclude Gettext strings", "translatepress-multilingual"); ?>
<?php __("Debug", "translatepress-multilingual"); ?>
<?php __("Custom languages", "translatepress-multilingual"); ?>
<?php __("Miscellaneous options", "translatepress-multilingual"); ?>
<?php __("Exclude strings & pages", "translatepress-multilingual"); ?>
<?php __("Automatic Translation Memory", "translatepress-multilingual"); ?>
<?php __("Serve same translation for similar text. The strings need to have a percentage of 95% similarity.<br>Helps prevent losing existing translation when correcting typos or making minor adjustments to the original text. <br>If a translation already exists for a very similar original string, it will automatically be used for the current original string.<br>Does not work when making changes to a text that is part of a translation block unless the new text is manually merged again in a translation block.<br>Each string needs to have a minimum of 50 characters.", "translatepress-multilingual"); ?>
<?php __("WARNING: This feature can negatively impact page loading times in secondary languages, particularly with large databases (for example websites with a lot of pages or products). If you experience slow loading times, disable this and try again.", "translatepress-multilingual"); ?>
<?php __("Fix missing dynamic content", "translatepress-multilingual"); ?>
<?php __("May help fix missing content inserted using JavaScript. <br> It shows dynamically inserted content in original language for a moment before the translation request is finished.", "translatepress-multilingual"); ?>
<?php __("Filter Gettext wrapping from post content and title", "translatepress-multilingual"); ?>
<?php __("Filters gettext wrapping such as #!trpst#trp-gettext from all updated post content and post title. Does not affect previous post content. <br/><strong>Database backup is recommended before switching on.</strong>", "translatepress-multilingual"); ?>
<?php __("Filter Gettext wrapping from post meta", "translatepress-multilingual"); ?>
<?php __("Filters gettext wrapping such as #!trpst#trp-gettext from all updated post meta. Does not affect previous post meta. <br/><strong>Database backup is recommended before switching on.</strong>", "translatepress-multilingual"); ?>
<?php __("Style", "translatepress-multilingual"); ?>
<?php __("Use shortcode settings", "translatepress-multilingual"); ?>
<?php __("Custom", "translatepress-multilingual"); ?>
<?php __("Language names", "translatepress-multilingual"); ?>
<?php __("Full names", "translatepress-multilingual"); ?>
<?php __("Short names", "translatepress-multilingual"); ?>
<?php __("Hide names", "translatepress-multilingual"); ?>
<?php __("Flag position", "translatepress-multilingual"); ?>
<?php __("Before text", "translatepress-multilingual"); ?>
<?php __("After text", "translatepress-multilingual"); ?>
<?php __("Hide flags", "translatepress-multilingual"); ?>
<?php __("Open on click", "translatepress-multilingual"); ?>
<?php __("Show opposite language", "translatepress-multilingual"); ?>
<?php __("Size", "translatepress-multilingual"); ?>
<?php __("Normal", "translatepress-multilingual"); ?>
<?php __("Large", "translatepress-multilingual"); ?>
<?php __("Flag shape", "translatepress-multilingual"); ?>
<?php __("Rectangle", "translatepress-multilingual"); ?>
<?php __("Square", "translatepress-multilingual"); ?>
<?php __("Rounded", "translatepress-multilingual"); ?>
<?php __("Transitions", "translatepress-multilingual"); ?>
<?php __("Background", "translatepress-multilingual"); ?>
<?php __("Hover background", "translatepress-multilingual"); ?>
<?php __("Hover text", "translatepress-multilingual"); ?>
<?php __("Border color", "translatepress-multilingual"); ?>
<?php __("Border width", "translatepress-multilingual"); ?>
<?php __("Border radius", "translatepress-multilingual"); ?>
<?php __("Flag radius", "translatepress-multilingual"); ?>
<?php __("Disable the legacy TranslatePress language switcher to use the customizable Elementor widget. <a href=\"%s\" target=\"_blank\" rel=\"noopener noreferrer\">Open language switcher settings</a>.", "translatepress-multilingual"); ?>
<?php __("The language switcher inherits styling options from shortcode. <a href=\"%s\" target=\"_blank\" rel=\"noopener noreferrer\">Open shortcode settings</a>.", "translatepress-multilingual"); ?>
<?php __("TranslatePress finished replacing the existing translations in your dictionary.", "translatepress-multilingual"); ?>
<?php __("Term added. Glossary terms only affect new automatic translations.", "translatepress-multilingual"); ?>
<?php __("Term updated.", "translatepress-multilingual"); ?>
<?php __("Term deleted.", "translatepress-multilingual"); ?>
<?php __("Are you sure you want to delete this term?", "translatepress-multilingual"); ?>
<?php __("Something went wrong. Please try again.", "translatepress-multilingual"); ?>
<?php __("Quick Edit", "translatepress-multilingual"); ?>
<?php __("Edit", "translatepress-multilingual"); ?>
<?php __("Delete", "translatepress-multilingual"); ?>
<?php __("Update", "translatepress-multilingual"); ?>
<?php __("No glossary terms match your search.", "translatepress-multilingual"); ?>
<?php __("No glossary terms found.", "translatepress-multilingual"); ?>
<?php __("Could not load glossary terms. Please reload the page.", "translatepress-multilingual"); ?>
<?php __("items", "translatepress-multilingual"); ?>
<?php __("of", "translatepress-multilingual"); ?>
<?php __("First page", "translatepress-multilingual"); ?>
<?php __("Previous page", "translatepress-multilingual"); ?>
<?php __("Next page", "translatepress-multilingual"); ?>
<?php __("Last page", "translatepress-multilingual"); ?>
<?php __("The inserted term was found in your existing translations, use the %s to make changes there.", "translatepress-multilingual"); ?>
<?php __("Please provide at least one existing translation to replace.", "translatepress-multilingual"); ?>
<?php __("You are about to bulk edit a potentially large amount of translations. This action cannot be undone. It is recommended to make a backup of the database before completing this action.", "translatepress-multilingual"); ?>
<?php __("Continue with replacing existing translations?", "translatepress-multilingual"); ?>
<?php __("No entries found.", "translatepress-multilingual"); ?>
<?php __("Original", "translatepress-multilingual"); ?>
<?php __("Translation", "translatepress-multilingual"); ?>
<?php __("Security check failed. Please reload the page and try again.", "translatepress-multilingual"); ?>
<?php __("You do not have permission to do this.", "translatepress-multilingual"); ?>
<?php __("Please enter the term in the default language.", "translatepress-multilingual"); ?>
<?php __("Please provide at least one translation for the term.", "translatepress-multilingual"); ?>
<?php __("The term “%s” already exists in the glossary.", "translatepress-multilingual"); ?>
<?php __("The term you are trying to edit no longer exists. Please reload the page.", "translatepress-multilingual"); ?>
<?php __("The term you are trying to delete no longer exists. Please reload the page.", "translatepress-multilingual"); ?>
<?php _n("%1$s: %2$d entry updated", "%1$s: %2$d entries updated", 1, "translatepress-multilingual"); ?>
<?php __("Replacement complete.", "translatepress-multilingual"); ?>
<?php __("This is a large replacement. %d entries were updated now and the rest will finish automatically in the background over the next few minutes.", "translatepress-multilingual"); ?>
<?php __("Google Translate v2", "translatepress-multilingual"); ?>
<?php __("Google Translate API Key", "translatepress-multilingual"); ?>
<?php __("Add your API Key here...", "translatepress-multilingual"); ?>
<?php __("Visit <a href=\"https://cloud.google.com/docs/authentication/api-keys\" target=\"_blank\">this link</a> to see how you can set up an API key, <strong>control API costs</strong> and set HTTP referrer restrictions.", "translatepress-multilingual"); ?>
<?php __("Your HTTP referrer is: %s", "translatepress-multilingual"); ?>
<?php __("There was an error on the server processing your Google Translate key.", "translatepress-multilingual"); ?>
<?php __("There was an error with your Google Translate key.", "translatepress-multilingual"); ?>
<?php __("Please check your TranslatePress license key.", "translatepress-multilingual"); ?>
<?php __("Create your Free Account", "translatepress-multilingual"); ?>
<?php __(" or ", "translatepress-multilingual"); ?>
<?php __(" Or %1$spurchase one here%2$s", "translatepress-multilingual"); ?>
<?php __("Your free account includes: ", "translatepress-multilingual"); ?>
<?php __("Get more AI Words and unlock all AI features with TranslatePress Pro.", "translatepress-multilingual"); ?>
<?php __(" words remaining. ", "translatepress-multilingual"); ?>
<?php __("Recheck", "translatepress-multilingual"); ?>
<?php __("Rechecking...", "translatepress-multilingual"); ?>
<?php __("Done.", "translatepress-multilingual"); ?>
<?php __("TranslatePress.com Account Page", "translatepress-multilingual"); ?>
<?php __("SEO support for page slug, page title, description and Facebook and Twitter social graph information. The HTML lang attribute is properly set.", "translatepress-multilingual"); ?>
<?php __("Enable Modules", "translatepress-multilingual"); ?>
<?php __("Enable Add-on modules to extend TranslatePress and enhance the functionality of your translated site.", "translatepress-multilingual"); ?>
<?php __("More functionality with TranslatePress Pro.", "translatepress-multilingual"); ?>
<?php __("Already a Pro User?", "translatepress-multilingual"); ?>
<?php __("Opens the WordPress “Add Plugins” page in a new tab. Upload and activate the TranslatePress Pro plugin there, then return to this tab — it will update automatically.", "translatepress-multilingual"); ?>
<?php __("Install TranslatePress Pro", "translatepress-multilingual"); ?>
<?php __("TranslatePress Pro is installed but not activated yet.", "translatepress-multilingual"); ?>
<?php __("Opens your Plugins page (filtered to TranslatePress) in a new tab. Activate the TranslatePress Pro plugin there, then return to this tab — it will update automatically.", "translatepress-multilingual"); ?>
<?php __("Activate TranslatePress Pro ↗", "translatepress-multilingual"); ?>
<?php __("TranslatePress Pro is active. Activate your license key to unlock the Pro add-ons below.", "translatepress-multilingual"); ?>
<?php __("Activate license", "translatepress-multilingual"); ?>
<?php __("This add-on is not available on your current plan.", "translatepress-multilingual"); ?>
<?php __("Continue", "translatepress-multilingual"); ?>
<?php __("The link you followed has expired. Please reload the page and try again.", "translatepress-multilingual"); ?>
<?php __("Your license key is disabled for this URL. Re-enable it from <a target=\"_blank\" href=\"https://translatepress.com/account/?utm_source=tp-onboarding&utm_medium=client-site&utm_campaign=activate-license\">https://translatepress.com/account</a> -> Manage Sites.", "translatepress-multilingual"); ?>
<?php __("<p><strong>License key mismatch.</strong> The license you entered doesn't match the TranslatePress version you have installed.</p><p>Please check that you've installed the correct version for your license from your TranslatePress account.</p>", "translatepress-multilingual"); ?>
<?php __("TranslatePress Account", "translatepress-multilingual"); ?>
<?php __("« Go Back", "translatepress-multilingual"); ?>
<?php __("Your license key is disabled for this URL. Re-enable it from <a target=\"_blank\" href=\"https://translatepress.com/account/?utm_source=tp-onboarding&utm_medium=client-site&utm_campaign=tp-ai\">https://translatepress.com/account</a> -> Manage Sites.", "translatepress-multilingual"); ?>
<?php __("Automatically translate your website using TranslatePress AI.", "translatepress-multilingual"); ?>
<?php __("your account.", "translatepress-multilingual"); ?>
<?php __("Skip and continue with manual translation »", "translatepress-multilingual"); ?>
<?php __("Creating a free account includes: ", "translatepress-multilingual"); ?>
<?php __("Are you a TranslatePress PRO user?", "translatepress-multilingual"); ?>
<?php __("Install TranslatePress Pro.", "translatepress-multilingual"); ?>
<?php __("Skip this step", "translatepress-multilingual"); ?>
<?php __("The email address you added is incorrect.", "translatepress-multilingual"); ?>
<?php __("Setup Complete", "translatepress-multilingual"); ?>
<?php __("You're ready to start translating!", "translatepress-multilingual"); ?>
<?php __("You have successfully set up TranslatePress for your website.", "translatepress-multilingual"); ?>
<?php __("Receive ", "translatepress-multilingual"); ?>
<?php __("Yes, send me multilingual growth tips.", "translatepress-multilingual"); ?>
<?php __("Start translating", "translatepress-multilingual"); ?>
<?php __("Sign Up and Start translating", "translatepress-multilingual"); ?>
<?php __("You are trying to add an invalid additional language. Please select a valid option.", "translatepress-multilingual"); ?>
<?php __("Please add an additional language.", "translatepress-multilingual"); ?>
<?php __("You are trying to add an invalid default language. Please select a valid option.", "translatepress-multilingual"); ?>
<?php __("You need to select a default language.", "translatepress-multilingual"); ?>
<?php __("Configure Site Languages", "translatepress-multilingual"); ?>
<?php __("Select the default and additional languages for your website.", "translatepress-multilingual"); ?>
<?php __("You can edit your site languages at any point.", "translatepress-multilingual"); ?>
<?php __("Additional Language", "translatepress-multilingual"); ?>
<?php __("Choose a secondary language...", "translatepress-multilingual"); ?>
<?php __("Add Language", "translatepress-multilingual"); ?>
<?php __("Choose a language...", "translatepress-multilingual"); ?>
<?php __("Add more than two languages with TranslatePress Pro.", "translatepress-multilingual"); ?>
<?php __("TranslatePress Pro is active. Activate your license key to add more languages.", "translatepress-multilingual"); ?>
<?php __("Set up Language Switcher", "translatepress-multilingual"); ?>
<?php __("Select the style of the language switcher. You will find more ways to display it, in plugin settings.", "translatepress-multilingual"); ?>
<?php __("Displays a small language drop-down across your website, in a corner of your choosing.", "translatepress-multilingual"); ?>
<?php __("Switcher Location", "translatepress-multilingual"); ?>
<?php __("Apply a Template", "translatepress-multilingual"); ?>
<?php __("You can customize the design later", "translatepress-multilingual"); ?>
<?php __("Default Template", "translatepress-multilingual"); ?>
<?php __("Dark Template", "translatepress-multilingual"); ?>
<?php __("Border Template", "translatepress-multilingual"); ?>
<?php __("Border", "translatepress-multilingual"); ?>
<?php __("Transparent Template", "translatepress-multilingual"); ?>
<?php __("Transparent", "translatepress-multilingual"); ?>
<?php __("Welcome to TranslatePress", "translatepress-multilingual"); ?>
<?php __("Quick guided setup to configure TranslatePress in no time!", "translatepress-multilingual"); ?>
<?php __("It takes less than a minute.", "translatepress-multilingual"); ?>
<?php __("Scanning item %1$d of %2$d...", "translatepress-multilingual"); ?>
<?php __("Manually translated", "translatepress-multilingual"); ?>
<?php __("Automatically translated", "translatepress-multilingual"); ?>
<?php __("Gettext file translation", "translatepress-multilingual"); ?>
<?php __("Not translated", "translatepress-multilingual"); ?>
<?php __("Bulk Actions", "translatepress-multilingual"); ?>
<?php __("Delete entries", "translatepress-multilingual"); ?>
<?php __("Filter", "translatepress-multilingual"); ?>
<?php __("Clear filters", "translatepress-multilingual"); ?>
<?php __("Add New", "translatepress-multilingual"); ?>
<?php __("Rescan plugins and theme for strings", "translatepress-multilingual"); ?>
<?php __("Scanning plugins and theme for strings...", "translatepress-multilingual"); ?>
<?php __("Plugins and theme scan is complete", "translatepress-multilingual"); ?>
<?php __("Plugins and theme scan did not finish due to an error", "translatepress-multilingual"); ?>
<?php __("Import / Export", "translatepress-multilingual"); ?>
<?php __("of", "translatepress-multilingual"); ?>
<?php __("See More", "translatepress-multilingual"); ?>
<?php __("See Less", "translatepress-multilingual"); ?>
<?php __("Apply", "translatepress-multilingual"); ?>
<?php __("No strings match your query.", "translatepress-multilingual"); ?>
<?php __("Try to rescan plugins and theme for strings.", "translatepress-multilingual"); ?>
<?php __("An error occurred while loading results. Most likely you were logged out. Reload page?", "translatepress-multilingual"); ?>
<?php __("found in translation", "translatepress-multilingual"); ?>
<?php __("Select All", "translatepress-multilingual"); ?>
<?php __("Select Visible", "translatepress-multilingual"); ?>
<?php __("You are about to perform this action on all the strings matching your filter, not just the visibly checked. To perform the action only to the visible strings click \"Select Visible\" from the table header dropdown.", "translatepress-multilingual"); ?>
<?php __("You are about to perform this action only on the visible strings. To perform the action on all the strings matching the filter click \"Select All\" from the table header dropdown.", "translatepress-multilingual"); ?>
<?php __("To continue please type the word:", "translatepress-multilingual"); ?>
<?php __("The word typed was incorrect. Action was cancelled.", "translatepress-multilingual"); ?>
<?php __("in", "translatepress-multilingual"); ?>
<?php __("Warning: This action cannot be undone. Deleting a string will remove its current translation. The original string will appear again in this interface after TranslatePress detects it. This action is NOT equivalent to excluding the string from being translated again.", "translatepress-multilingual"); ?>
<?php __("%d original entries and their translations were deleted.", "translatepress-multilingual"); ?>
<?php __("Navigate to next page", "translatepress-multilingual"); ?>
<?php __("Navigate to previous page", "translatepress-multilingual"); ?>
<?php __("Navigate to first page", "translatepress-multilingual"); ?>
<?php __("Navigate to last page", "translatepress-multilingual"); ?>
<?php __("Type a page number to navigate to", "translatepress-multilingual"); ?>
<?php __("Incorrect page number. Type a page number between 1 and total number of pages", "translatepress-multilingual"); ?>
<?php __("Search original and translated strings containing typed keywords while also matching selected filters. Place string in quotes for exact match: \"string\"", "translatepress-multilingual"); ?>
<?php __("Filter strings according to selected translation status, filters and keywords and selected filters", "translatepress-multilingual"); ?>
<?php __("Removes selected filters", "translatepress-multilingual"); ?>
<?php __("See options for selecting all strings", "translatepress-multilingual"); ?>
<?php __("Click to sort strings by this column", "translatepress-multilingual"); ?>
<?php __("The ID of the WordPress post where this string was detected. Empty if the string is not associated with a specific post.", "translatepress-multilingual"); ?>
<?php __("Language in which the translation status filter applies. Leave unselected for the translation status to apply to ANY language", "translatepress-multilingual"); ?>
<?php __("Slugs that are not found in either one of the other categories.", "translatepress-multilingual"); ?>
<?php __("Plugins and Theme String Translation", "translatepress-multilingual"); ?>
<?php __("Gettext", "translatepress-multilingual"); ?>
<?php __("Search Gettext Strings", "translatepress-multilingual"); ?>
<?php __("Post ID", "translatepress-multilingual"); ?>
<?php __("Original String", "translatepress-multilingual"); ?>
<?php __("Filter by domain", "translatepress-multilingual"); ?>
<?php __("Filter by type", "translatepress-multilingual"); ?>
<?php __("Email text", "translatepress-multilingual"); ?>
<?php __("Emails String Translation", "translatepress-multilingual"); ?>
<?php __("Emails", "translatepress-multilingual"); ?>
<?php __("Search Email Strings", "translatepress-multilingual"); ?>
<?php __("User Inputted String Translation", "translatepress-multilingual"); ?>
<?php __("Regular", "translatepress-multilingual"); ?>
<?php __("Search Regular Strings", "translatepress-multilingual"); ?>
<?php __("Filter by Translation Block", "translatepress-multilingual"); ?>
<?php __("URL Slugs Translation", "translatepress-multilingual"); ?>
<?php __("String Translation Editor", "translatepress-multilingual"); ?>
<?php __("Every minute", "translatepress-multilingual"); ?>
<?php __("Could not load the background task.", "translatepress-multilingual"); ?>
<?php __("Waiting to start background processing...", "translatepress-multilingual"); ?>
<?php __("Background processing could not start.", "translatepress-multilingual"); ?>
<?php __("Background processing completed.", "translatepress-multilingual"); ?>
<?php __("A previous batch item failed.", "translatepress-multilingual"); ?>
<?php __("TranslatePress background processing did not complete successfully.", "translatepress-multilingual"); ?>
<?php __("Error: %s", "translatepress-multilingual"); ?>
<?php __("You do not have permission to view this task status.", "translatepress-multilingual"); ?>
<?php __("Invalid batch task.", "translatepress-multilingual"); ?>
<?php __("TranslatePress background processing completed successfully.", "translatepress-multilingual"); ?>
<?php __("TranslatePress is processing a background task.", "translatepress-multilingual"); ?>
<?php __("Processing %s...", "translatepress-multilingual"); ?>
<?php __("%s is optimizing gettext database tables in the background. Translations continue to work while this runs.", "translatepress-multilingual"); ?>
<?php __("TranslatePress gettext database optimization completed successfully.", "translatepress-multilingual"); ?>
<?php __("TranslatePress has detected and cleaned up some failed translation entries in your database following %s. No further action is required.", "translatepress-multilingual"); ?>
<?php __("an isolated incident", "translatepress-multilingual"); ?>
<?php __("Post Slug", "translatepress-multilingual"); ?>
<?php __("Invalid language code", "translatepress-multilingual"); ?>
<?php __("We've detected you might be speaking a different language. Do you want to change to:", "translatepress-multilingual"); ?>
<?php __("Change Language", "translatepress-multilingual"); ?>
<?php __("Close and do not switch language", "translatepress-multilingual"); ?>
<?php __("First by browser language, then IP address (recommended)", "translatepress-multilingual"); ?>
<?php __("First by IP address, then by browser language", "translatepress-multilingual"); ?>
<?php __("Only by browser language", "translatepress-multilingual"); ?>
<?php __("Only by IP address", "translatepress-multilingual"); ?>
<?php __("A popup appears asking the user if they want to be redirected", "translatepress-multilingual"); ?>
<?php __("Redirect directly (*not recommended)", "translatepress-multilingual"); ?>
<?php __("Pop-up window over the content", "translatepress-multilingual"); ?>
<?php __("Hello bar before the content", "translatepress-multilingual"); ?>
<?php __("Automatic User Language Detection requires a newer version of TranslatePress to use its visual settings interface. The legacy settings form will remain available until TranslatePress is updated.", "translatepress-multilingual"); ?>
<?php __("Update TranslatePress", "translatepress-multilingual"); ?>
<?php __("WARNING. Cannot determine your language preference based on your current IP.<br>This is most likely because the website is on a local environment.", "translatepress-multilingual"); ?>
<?php __("Invalid settings.", "translatepress-multilingual"); ?>
<?php __("Go to <a href=\"%s\" target=\"_self\">Advanced</a> tab to change this feature's settings", "translatepress-multilingual"); ?>
<?php __("Bad request. There was an error accessing the DeepL API.", "translatepress-multilingual"); ?>
<?php __("The API key entered is invalid.", "translatepress-multilingual"); ?>
<?php __("The API resource could not be found.", "translatepress-multilingual"); ?>
<?php __("The request size is too large.", "translatepress-multilingual"); ?>
<?php __("The request is too long.", "translatepress-multilingual"); ?>
<?php __("Too many requests. Please try again later.", "translatepress-multilingual"); ?>
<?php __("Your translation quota has been reached.", "translatepress-multilingual"); ?>
<?php __("We could not process your request. Please try again later.", "translatepress-multilingual"); ?>
<?php __("There is an error on the DeepL service and your request could not be processed.", "translatepress-multilingual"); ?>
<?php __("DeepL API Type", "translatepress-multilingual"); ?>
<?php __("Pro", "translatepress-multilingual"); ?>
<?php __("Free", "translatepress-multilingual"); ?>
<?php __("Select the type of DeepL API you want to use.", "translatepress-multilingual"); ?>
<?php __("DeepL API Key", "translatepress-multilingual"); ?>
<?php __("Visit <a href=\"%s\" target=\"_blank\">this link</a> to see how you can set up an API key and control API costs.", "translatepress-multilingual"); ?>
<?php __("Translator", "translatepress-multilingual"); ?>
<?php __(" TranslatePress Settings", "translatepress-multilingual"); ?>
<?php __("Allow this user to translate the website.", "translatepress-multilingual"); ?>
<?php __("Update aborted! Unknown gettext lookup hash migration phase: %s.", "translatepress-multilingual"); ?>
<?php __("Update aborted! Could not find an available gettext original_id index name for table %s.", "translatepress-multilingual"); ?>
<?php __("Update aborted! Gettext lookup hash migration cannot process invalid ID %1$d in table %2$s. Repair the table ID schema and retry.", "translatepress-multilingual"); ?>
<?php __("Update aborted! Table %1$s still references %2$d duplicate gettext original ids.", "translatepress-multilingual"); ?>
<?php __("Update aborted! Gettext original meta still references %d duplicate original ids.", "translatepress-multilingual"); ?>
<?php __("Gettext database optimization completed.", "translatepress-multilingual"); ?>
<?php __("Deduplicating gettext translation tables...", "translatepress-multilingual"); ?>
<?php __("Migrating gettext original lookup hashes...", "translatepress-multilingual"); ?>
<?php __("Preparing the gettext originals lookup index...", "translatepress-multilingual"); ?>
<?php __("Updating gettext runtime statuses...", "translatepress-multilingual"); ?>
<?php __("Finishing gettext database optimization...", "translatepress-multilingual"); ?>
<?php __("Updating gettext runtime statuses for language %s...", "translatepress-multilingual"); ?>
<?php __("Resolving missing gettext original ids in %s...", "translatepress-multilingual"); ?>
<?php __("Preparing gettext table %s...", "translatepress-multilingual"); ?>
<?php __("Removing invalid gettext rows from %s...", "translatepress-multilingual"); ?>
<?php __("Prepared gettext original ids in %s...", "translatepress-multilingual"); ?>
<?php __("Normalizing plural forms in %s...", "translatepress-multilingual"); ?>
<?php __("Processing duplicate gettext rows in %s...", "translatepress-multilingual"); ?>
<?php __("Building duplicate gettext map for %s...", "translatepress-multilingual"); ?>
<?php __("Verifying gettext table %s...", "translatepress-multilingual"); ?>
<?php __("Deleting duplicate gettext rows from %s...", "translatepress-multilingual"); ?>
<?php __("Rechecking duplicate gettext rows in %s...", "translatepress-multilingual"); ?>
<?php __("Adding unique gettext index for %s...", "translatepress-multilingual"); ?>
<?php __("Finished gettext table %s.", "translatepress-multilingual"); ?>
<?php __("(inactive)", "translatepress-multilingual"); ?>
<?php __("Taxonomy Slugs", "translatepress-multilingual"); ?>
<?php __("Search Taxonomy Slugs", "translatepress-multilingual"); ?>
<?php __("Taxonomy Slug", "translatepress-multilingual"); ?>
<?php __("Term Slugs", "translatepress-multilingual"); ?>
<?php __("Search Term Slugs", "translatepress-multilingual"); ?>
<?php __("Term Slug", "translatepress-multilingual"); ?>
<?php __("Taxonomy", "translatepress-multilingual"); ?>
<?php __("Filter by Taxonomy", "translatepress-multilingual"); ?>
<?php __("Post Slugs", "translatepress-multilingual"); ?>
<?php __("Search Post Slugs", "translatepress-multilingual"); ?>
<?php __("Post Type", "translatepress-multilingual"); ?>
<?php __("Filter by Post Type", "translatepress-multilingual"); ?>
<?php __("Published", "translatepress-multilingual"); ?>
<?php __("Any Post Status", "translatepress-multilingual"); ?>
<?php __("Post Type Base Slugs", "translatepress-multilingual"); ?>
<?php __("Post Type Base Slug", "translatepress-multilingual"); ?>
<?php __("Search Post Type Base Slugs", "translatepress-multilingual"); ?>
<?php __("WooCommerce Slugs", "translatepress-multilingual"); ?>
<?php __("WooCommerce Slug", "translatepress-multilingual"); ?>
<?php __("Search WooCommerce Slugs", "translatepress-multilingual"); ?>
<?php __("Other Slugs", "translatepress-multilingual"); ?>
<?php __("Search Other Slugs", "translatepress-multilingual"); ?>
